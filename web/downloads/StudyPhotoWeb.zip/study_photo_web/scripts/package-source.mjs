import { mkdirSync, readdirSync, readFileSync, writeFileSync } from 'node:fs';
import { fileURLToPath } from 'node:url';
import { join } from 'node:path';
import { zipSync } from 'fflate';

const root = fileURLToPath(new URL('../', import.meta.url));
const files = {};
const rootFiles = new Set(['App.tsx', 'index.ts', 'app.json', 'package.json', 'package-lock.json', 'tsconfig.json', 'LICENSE', 'README.md', '.gitignore']);
const directories = new Set(['assets', 'src', 'site', 'scripts']);
function collect(directory, relative = '') {
  for (const entry of readdirSync(directory, { withFileTypes: true })) {
    if (!relative && !(entry.isDirectory() ? directories.has(entry.name) : rootFiles.has(entry.name))) continue;
    const path = relative ? `${relative}/${entry.name}` : entry.name;
    if (entry.isDirectory()) collect(join(directory, entry.name), path);
    else if (entry.isFile()) files[`study_photo_web/${path}`] = readFileSync(join(directory, entry.name));
  }
}
collect(root);
mkdirSync(join(root, 'dist/downloads'), { recursive: true });
writeFileSync(join(root, 'dist/downloads/StudyPhotoWeb.zip'), zipSync(files, { level: 6 }));
console.log(`Packaged ${Object.keys(files).length} source files; node_modules, .expo and dist excluded.`);
