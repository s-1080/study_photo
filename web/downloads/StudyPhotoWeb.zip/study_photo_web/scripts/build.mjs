import { execFileSync } from 'node:child_process';
import { cpSync, mkdirSync, readFileSync, rmSync, writeFileSync } from 'node:fs';
import { fileURLToPath } from 'node:url';

const root = fileURLToPath(new URL('../', import.meta.url));
const output = new URL('../dist/', import.meta.url);
rmSync(output, { recursive: true, force: true });
mkdirSync(output, { recursive: true });
cpSync(new URL('../site/', import.meta.url), output, { recursive: true });
execFileSync(process.execPath, [
  fileURLToPath(new URL('../node_modules/expo/bin/cli', import.meta.url)),
  'export', '--platform', 'web', '--output-dir', 'dist/app',
], { cwd: root, stdio: 'inherit' });

const appHTML = new URL('../dist/app/index.html', import.meta.url);
let html = readFileSync(appHTML, 'utf8');
html = html.replace(/<html\b[^>]*>/, '<html lang="ja">')
  .replace(/<meta\s+name="viewport"[^>]*>/, '<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">')
  .replace('</head>', '<meta name="robots" content="noindex, nofollow, noarchive"><meta name="theme-color" content="#f7f8f2"><meta name="apple-mobile-web-app-capable" content="yes"><meta name="apple-mobile-web-app-title" content="StudyPhoto"><link rel="manifest" href="./manifest.webmanifest"><link rel="apple-touch-icon" href="./icon.png"></head>');
writeFileSync(appHTML, html);
cpSync(new URL('../assets/icon.png', import.meta.url), new URL('../dist/app/icon.png', import.meta.url));
writeFileSync(new URL('../dist/app/manifest.webmanifest', import.meta.url), JSON.stringify({
  name: 'StudyPhoto', short_name: 'StudyPhoto', lang: 'ja', start_url: './', scope: './',
  display: 'standalone', background_color: '#f7f8f2', theme_color: '#f7f8f2',
  icons: [{ src: './icon.png', sizes: '1024x1024', type: 'image/png' }],
}, null, 2));
writeFileSync(new URL('../dist/.nojekyll', import.meta.url), '');
await import('./package-source.mjs');
console.log('Built landing page and Expo Web app in dist/.');
