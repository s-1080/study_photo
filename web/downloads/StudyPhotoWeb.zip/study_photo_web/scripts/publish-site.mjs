import { execFileSync } from 'node:child_process';
import { readdirSync, readFileSync } from 'node:fs';
import { fileURLToPath } from 'node:url';
import { join } from 'node:path';

const repository = 's-1080/study_photo';
const endpoint = `repos/${repository}`;
const branch = 'gh-pages';
const files = [];
function collect(directory, relative = '') {
  for (const entry of readdirSync(directory, { withFileTypes: true })) {
    const path = relative ? `${relative}/${entry.name}` : entry.name;
    if (entry.isDirectory()) collect(join(directory, entry.name), path);
    else if (entry.isFile()) files.push({ path, content: readFileSync(join(directory, entry.name)) });
  }
}
collect(fileURLToPath(new URL('../dist/', import.meta.url)));
if (!files.some(file => file.path === 'app/index.html')) throw new Error('Run npm run build before publishing.');
// Serve the same Web guide at the Pages root; only its asset paths differ.
let rootHTML = readFileSync(new URL('../dist/index.html', import.meta.url), 'utf8');
for (const path of ['styles.css', 'site.js', 'app/', 'downloads/StudyPhotoWeb.zip']) {
  const relative = `="./${path}"`;
  if (!rootHTML.includes(relative)) throw new Error(`Missing guide link: ${relative}`);
  rootHTML = rootHTML.replaceAll(relative, `="./web/${path}"`);
}
const rootPage = Buffer.from(rootHTML);

function github(path, method = 'GET', payload) {
  const args = ['api', path, '--method', method];
  if (payload !== undefined) args.push('--input', '-');
  const output = execFileSync('gh', args, { input: payload === undefined ? undefined : JSON.stringify(payload), encoding: 'utf8' }).trim();
  return output ? JSON.parse(output) : null;
}
const pages = github(`${endpoint}/pages`);
if (pages.source?.branch !== branch || pages.source?.path !== '/' || !pages.https_enforced) {
  throw new Error('Expected HTTPS GitHub Pages from gh-pages root. Configuration left unchanged.');
}
const previous = github(`${endpoint}/git/ref/heads/${branch}`);
const previousCommit = github(`${endpoint}/git/commits/${previous.object.sha}`);
const webTree = github(`${endpoint}/git/trees`, 'POST', {
  tree: files.map(({ path, content }) => ({
    path, mode: '100644', type: 'blob',
    sha: github(`${endpoint}/git/blobs`, 'POST', { content: content.toString('base64'), encoding: 'base64' }).sha,
  })),
});
const tree = github(`${endpoint}/git/trees`, 'POST', {
  tree: [
    { path: 'index.html', mode: '100644', type: 'blob',
      sha: github(`${endpoint}/git/blobs`, 'POST', { content: rootPage.toString('base64'), encoding: 'base64' }).sha },
    { path: 'web', mode: '040000', type: 'tree', sha: webTree.sha },
  ],
});
const commit = github(`${endpoint}/git/commits`, 'POST', { message: 'Publish StudyPhoto Web guide at Pages root', tree: tree.sha, parents: [previous.object.sha] });
github(`${endpoint}/git/refs/heads/${branch}`, 'PATCH', { sha: commit.sha, force: false });
console.log(`Publication commit: ${commit.sha}`);
console.log(`Web guide: ${pages.html_url}`);
console.log(`Camera app: ${pages.html_url}web/app/`);
console.log('The Pages root serves the Web guide; other root files and main were preserved.');
