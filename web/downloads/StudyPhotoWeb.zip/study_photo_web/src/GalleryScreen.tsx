import React, { useState, useEffect, useCallback, useRef } from 'react';
import { StyleSheet, Text, View, TouchableOpacity, FlatList, Image, ScrollView, ActivityIndicator } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { getSavedPhotos, exportPhotos, copyPhotoToClipboard, deleteSelectedPhotos } from './PhotoManager';
import Brand from './Brand';
import { colors } from './theme';
import { showMessage, confirmAction } from './dialogs';

type Props = {
  onBack: () => void;
};

const numColumns = 3;
const gridPadding = 16;
const gridGap = 8;
const maxPreviewZoom = 4;

type Point = { x: number; y: number };
type PreviewGesture =
  | { kind: 'swipe' | 'pan'; start: Point; offset: Point }
  | { kind: 'pinch'; distance: number; zoom: number; offset: Point; center: Point };

export default function GalleryScreen({ onBack }: Props) {
  const [isSelecting, setIsSelecting] = useState(false);
  const [photos, setPhotos] = useState<string[]>([]);
  const [selectedPhotos, setSelectedPhotos] = useState<Set<string>>(new Set());
  const [previewUri, setPreviewUri] = useState<string | null>(null);
  const [isProcessing, setIsProcessing] = useState(false);
  const [gridWidth, setGridWidth] = useState(0);
  const [isLoading, setIsLoading] = useState(true);
  const [loadError, setLoadError] = useState<string | null>(null);
  const [isPreviewScrolling, setIsPreviewScrolling] = useState(false);
  const operation = useRef(false);
  const previewFrame = useRef<HTMLDivElement | null>(null);
  const previewImage = useRef<HTMLImageElement | null>(null);
  const pointers = useRef(new Map<number, Point>());
  const gesture = useRef<PreviewGesture | null>(null);
  const zoomRef = useRef(1);
  const offsetRef = useRef<Point>({ x: 0, y: 0 });
  const [previewZoom, setPreviewZoom] = useState(1);
  const [previewOffset, setPreviewOffset] = useState<Point>({ x: 0, y: 0 });
  const busy = isProcessing || isLoading;

  const loadPhotos = useCallback(async () => {
    setIsLoading(true);
    setLoadError(null);
    try {
      const uris = (await getSavedPhotos()).reverse();
      setPhotos(uris);
      const available = new Set(uris);
      setSelectedPhotos((selected) => new Set(Array.from(selected).filter((uri) => available.has(uri))));
      setPreviewUri((current) => current && !available.has(current) ? uris[0] ?? null : current);
    } catch (error) {
      setLoadError(error instanceof Error ? error.message : '写真を読み込めませんでした。');
    } finally {
      setIsLoading(false);
    }
  }, []);

  useEffect(() => {
    void loadPhotos();
    const refresh = () => { if (!operation.current) void loadPhotos(); };
    window.addEventListener('focus', refresh);
    return () => window.removeEventListener('focus', refresh);
  }, [loadPhotos]);

  const beginOperation = () => {
    if (operation.current || isLoading) return false;
    operation.current = true;
    setIsProcessing(true);
    return true;
  };
  const finishOperation = () => {
    operation.current = false;
    setIsProcessing(false);
  };
  const showFailure = (title: string, error: unknown) =>
    showMessage(title, error instanceof Error ? error.message : 'ブラウザの権限や保存容量を確認して、再試行してください。');

  const describeExport = async (outcome: 'shared' | 'downloaded' | 'cancelled', count: number) => {
    if (outcome === 'shared') {
      await showMessage('共有メニュー', `${count}枚の写真を共有しました。写真アプリへの保存は、共有メニューで「画像を保存」を選んだ場合に行われます。`);
    } else if (outcome === 'downloaded') {
      await showMessage('ダウンロード', `${count}枚の写真のダウンロードを開始しました。ブラウザのダウンロード一覧を確認してください。複数枚の場合は、複数ファイルのダウンロードを許可する必要があります。写真アプリには自動で保存されません。`);
    }
  };

  const toggleSelection = (uri: string) => {
    if (busy) return;
    setIsSelecting(true);
    setSelectedPhotos((selected) => {
      const next = new Set(selected);
      if (next.has(uri)) next.delete(uri);
      else next.add(uri);
      return next;
    });
  };

  const handleExport = async () => {
    if (selectedPhotos.size === 0 || !beginOperation()) return;
    const uris = Array.from(selectedPhotos);
    try {
      const outcome = await exportPhotos(uris);
      if (outcome !== 'cancelled') setSelectedPhotos(new Set());
      await describeExport(outcome, uris.length);
    } catch (error) {
      await showFailure('写真を保存できませんでした', error);
    } finally {
      finishOperation();
    }
  };

  const handleDeleteSelected = async () => {
    if (selectedPhotos.size === 0 || !beginOperation()) return;
    const uris = Array.from(selectedPhotos);
    try {
      const confirmed = await confirmAction('選択した写真を削除',
        `${uris.length}枚をこのブラウザのアプリ内から削除します。共有・ダウンロードしたファイルや写真アプリの画像は削除されません。`,
        { confirmLabel: '削除する', destructive: true });
      if (!confirmed) return;
      await deleteSelectedPhotos(uris);
      setSelectedPhotos(new Set());
      await loadPhotos();
    } catch (error) {
      await loadPhotos();
      await showFailure('写真を削除できませんでした', error);
    } finally {
      finishOperation();
    }
  };

  const handlePreviewAction = async (action: 'copy' | 'save') => {
    if (!previewUri || isPreviewScrolling || !beginOperation()) return;
    try {
      if (action === 'copy') {
        await copyPhotoToClipboard(previewUri);
        await showMessage('コピー完了', '画像をコピーしました。画像の貼り付けに対応したアプリに貼り付けできます。');
      } else {
        await describeExport(await exportPhotos([previewUri]), 1);
      }
    } catch (error) {
      await showFailure(action === 'copy' ? '画像をコピーできませんでした' : '写真を保存できませんでした', error);
    } finally {
      finishOperation();
    }
  };

  const handlePress = (uri: string) => {
    if (busy) return;
    if (isSelecting) {
      toggleSelection(uri);
    } else {
      setPreviewUri(uri);
    }
  };

  const applyPreviewTransform = (zoom: number, desired: Point) => {
    const nextZoom = Math.max(1, Math.min(maxPreviewZoom, zoom));
    const frame = previewFrame.current;
    const image = previewImage.current;
    let x = 0;
    let y = 0;
    if (frame && image?.naturalWidth && image.naturalHeight) {
      const width = frame.clientWidth;
      const height = frame.clientHeight;
      const ratio = image.naturalWidth / image.naturalHeight;
      const fittedWidth = Math.min(width, height * ratio);
      const fittedHeight = Math.min(height, width / ratio);
      const maxX = Math.max(0, (fittedWidth * nextZoom - width) / 2);
      const maxY = Math.max(0, (fittedHeight * nextZoom - height) / 2);
      x = Math.max(-maxX, Math.min(maxX, desired.x));
      y = Math.max(-maxY, Math.min(maxY, desired.y));
    }
    zoomRef.current = nextZoom;
    offsetRef.current = { x, y };
    setPreviewZoom(nextZoom);
    setPreviewOffset(offsetRef.current);
  };

  const resetPreview = () => {
    pointers.current.clear();
    gesture.current = null;
    zoomRef.current = 1;
    offsetRef.current = { x: 0, y: 0 };
    setPreviewZoom(1);
    setPreviewOffset(offsetRef.current);
    setIsPreviewScrolling(false);
  };

  const imageSize = Math.max(44, (gridWidth - gridPadding * 2 - gridGap * (numColumns - 1)) / numColumns);
  const renderItem = ({ item, index }: { item: string; index: number }) => {
    const isSelected = selectedPhotos.has(item);
    return (
      <TouchableOpacity
        style={[styles.imageContainer, { width: imageSize, height: imageSize }, busy && styles.disabled]}
        accessibilityRole="button"
        accessibilityLabel={`写真 ${index + 1}`}
        accessibilityHint={isSelecting ? 'タップして選択を切り替えます' : 'タップして表示、長押しで選択します'}
        accessibilityState={{ selected: isSelected, disabled: busy }}
        disabled={busy}
        onPress={() => handlePress(item)}
        onLongPress={() => toggleSelection(item)}
      >
        <Image source={{ uri: item }} style={styles.image} />
        {isSelected && (
          <View style={styles.selectedOverlay} pointerEvents="none">
            <View style={styles.checkCircle}><Text style={styles.checkmark}>✓</Text></View>
          </View>
        )}
      </TouchableOpacity>
    );
  };

  const processingIndicator = isProcessing ? (
    <View style={styles.processing} accessibilityLiveRegion="polite">
      <ActivityIndicator color={colors.green} />
      <Text style={styles.bodyText}>処理中…</Text>
    </View>
  ) : null;
  const storageError = loadError ? (
    <View style={styles.emptyCard} accessibilityLiveRegion="assertive">
      <Text style={styles.emptyTitle}>写真を読み込めませんでした</Text>
      <Text style={styles.bodyText}>{loadError}</Text>
      <TouchableOpacity style={[styles.button, styles.outlineButton, busy && styles.disabled]}
        accessibilityRole="button" accessibilityLabel="写真を再読み込み"
        disabled={busy} onPress={() => { void loadPhotos(); }}>
        <Text style={styles.outlineButtonText}>再読み込み</Text>
      </TouchableOpacity>
    </View>
  ) : null;

  if (previewUri) {
    const actionsDisabled = busy || isPreviewScrolling;
    const previewIndex = photos.indexOf(previewUri);
    const movePreview = (direction: number) => {
      if (busy) return;
      const next = photos[previewIndex + direction];
      if (next) {
        resetPreview();
        setPreviewUri(next);
      }
    };
    const finishPointer = (event: React.PointerEvent<HTMLDivElement>, cancelled = false) => {
      if (!pointers.current.has(event.pointerId)) return;
      const currentGesture = gesture.current;
      const dx = currentGesture?.kind === 'swipe' ? event.clientX - currentGesture.start.x : 0;
      const dy = currentGesture?.kind === 'swipe' ? event.clientY - currentGesture.start.y : 0;
      const navigate = !cancelled && currentGesture?.kind === 'swipe' && pointers.current.size === 1
        && Math.abs(dx) >= 40 && Math.abs(dx) > Math.abs(dy);
      pointers.current.delete(event.pointerId);
      gesture.current = null;
      if (pointers.current.size === 0) setIsPreviewScrolling(false);
      if (navigate) movePreview(dx < 0 ? 1 : -1);
    };
    return (
      <SafeAreaView style={styles.container}>
        <ScrollView style={styles.previewChrome} contentContainerStyle={styles.previewHeader}>
          <TouchableOpacity
            style={[styles.navButton, actionsDisabled && styles.disabled]}
            accessibilityRole="button" accessibilityLabel="プレビューを閉じる"
            accessibilityState={{ disabled: actionsDisabled }} disabled={actionsDisabled}
            onPress={() => { resetPreview(); setPreviewUri(null); }}
          >
            <Text style={styles.navButtonText}>✕ 閉じる</Text>
          </TouchableOpacity>
          <Text style={styles.photoCounter} accessibilityLiveRegion="polite">
            {photos.indexOf(previewUri) + 1} / {photos.length} 枚
          </Text>
        </ScrollView>
        <div
          ref={previewFrame}
          role="group"
          aria-label="写真プレビュー。左右にスワイプで移動、2本指で拡大縮小"
          tabIndex={0}
          style={{ flex: 1, minHeight: 80, minWidth: 0, position: 'relative', display: 'flex', background: colors.camera,
            overflow: 'hidden', touchAction: 'none', userSelect: 'none' }}
          onKeyDown={(event) => {
            if (previewZoom === 1 && (event.key === 'ArrowLeft' || event.key === 'ArrowRight')) {
              event.preventDefault();
              movePreview(event.key === 'ArrowLeft' ? -1 : 1);
            }
          }}
          onPointerDown={(event) => {
            if (busy || event.button !== 0) return;
            event.currentTarget.setPointerCapture(event.pointerId);
            pointers.current.set(event.pointerId, { x: event.clientX, y: event.clientY });
            setIsPreviewScrolling(true);
            if (pointers.current.size === 1) {
              gesture.current = { kind: zoomRef.current > 1 ? 'pan' : 'swipe',
                start: { x: event.clientX, y: event.clientY }, offset: offsetRef.current };
            } else if (pointers.current.size === 2) {
              const [a, b] = Array.from(pointers.current.values());
              gesture.current = { kind: 'pinch', distance: Math.hypot(a.x - b.x, a.y - b.y),
                zoom: zoomRef.current, offset: offsetRef.current,
                center: { x: (a.x + b.x) / 2, y: (a.y + b.y) / 2 } };
            }
          }}
          onPointerMove={(event) => {
            if (!pointers.current.has(event.pointerId)) return;
            pointers.current.set(event.pointerId, { x: event.clientX, y: event.clientY });
            const currentGesture = gesture.current;
            if (currentGesture?.kind === 'pinch' && pointers.current.size >= 2) {
              const [a, b] = Array.from(pointers.current.values());
              const nextZoom = Math.max(1, Math.min(maxPreviewZoom,
                currentGesture.zoom * Math.hypot(a.x - b.x, a.y - b.y) / Math.max(1, currentGesture.distance)));
              const ratio = nextZoom / currentGesture.zoom;
              const frame = previewFrame.current?.getBoundingClientRect();
              if (!frame) return;
              const center = { x: (a.x + b.x) / 2 - frame.left - frame.width / 2,
                y: (a.y + b.y) / 2 - frame.top - frame.height / 2 };
              const start = { x: currentGesture.center.x - frame.left - frame.width / 2,
                y: currentGesture.center.y - frame.top - frame.height / 2 };
              applyPreviewTransform(nextZoom, {
                x: center.x - (start.x - currentGesture.offset.x) * ratio,
                y: center.y - (start.y - currentGesture.offset.y) * ratio,
              });
            } else if (currentGesture?.kind === 'pan') {
              applyPreviewTransform(zoomRef.current, {
                x: currentGesture.offset.x + event.clientX - currentGesture.start.x,
                y: currentGesture.offset.y + event.clientY - currentGesture.start.y,
              });
            }
          }}
          onPointerUp={(event) => finishPointer(event)}
          onPointerCancel={(event) => finishPointer(event, true)}
          onLostPointerCapture={(event) => finishPointer(event, true)}
        >
          <img ref={previewImage} src={previewUri} alt={`写真 ${previewIndex + 1}`} draggable={false}
            style={{ position: 'absolute', inset: 0, width: '100%', height: '100%', objectFit: 'contain',
              pointerEvents: 'none', transform: `translate(${previewOffset.x}px, ${previewOffset.y}px) scale(${previewZoom})` }} />
        </div>
        <ScrollView style={styles.previewChrome} contentContainerStyle={styles.previewFooter}>
          <View style={styles.previewActions}>
            <TouchableOpacity
              style={[styles.button, styles.outlineButton, styles.previewAction, actionsDisabled && styles.disabled]}
              accessibilityRole="button" accessibilityLabel="表示中の写真をコピー"
              accessibilityState={{ disabled: actionsDisabled }} disabled={actionsDisabled}
              onPress={() => handlePreviewAction('copy')}
            >
              <Text style={styles.outlineButtonText}>コピー</Text>
            </TouchableOpacity>
            <TouchableOpacity
              style={[styles.button, styles.primaryButton, styles.previewAction, actionsDisabled && styles.disabled]}
              accessibilityRole="button" accessibilityLabel="表示中の写真を共有またはダウンロード"
              accessibilityState={{ disabled: actionsDisabled }} disabled={actionsDisabled}
              onPress={() => handlePreviewAction('save')}
            >
              <Text style={styles.primaryButtonText}>写真に保存</Text>
            </TouchableOpacity>
          </View>
          {processingIndicator}
          {storageError}
        </ScrollView>
      </SafeAreaView>
    );
  }

  return (
    <SafeAreaView style={styles.container}>
      <FlatList
        key="grid"
        style={styles.list}
        onLayout={(event) => setGridWidth(event.nativeEvent.layout.width)}
        data={gridWidth > 0 ? photos : []}
        extraData={{ selectedPhotos, busy, imageSize, isSelecting, loadError }}
        contentContainerStyle={styles.gridContent}
        columnWrapperStyle={styles.gridRow}
        keyExtractor={(item) => item}
        numColumns={numColumns}
        renderItem={renderItem}
        ListHeaderComponent={
          <View style={styles.galleryHeader}>
            <Brand />
            <View style={styles.navigation}>
              <TouchableOpacity onPress={onBack} style={[styles.navButton, busy && styles.disabled]}
                accessibilityRole="button" accessibilityLabel="カメラへ戻る"
                accessibilityState={{ disabled: busy }} disabled={busy}>
                <Text style={styles.navButtonText}>◀ カメラへ</Text>
              </TouchableOpacity>
              <TouchableOpacity style={[styles.navButton, busy && styles.disabled]}
                accessibilityRole="button" accessibilityLabel={isSelecting ? '写真の選択を完了' : '写真を選択'}
                accessibilityState={{ disabled: busy }} disabled={busy}
                onPress={() => {
                  setIsSelecting(!isSelecting);
                  setSelectedPhotos(new Set());
                }}>
                <Text style={styles.navButtonText}>{isSelecting ? '完了' : '選択'}</Text>
              </TouchableOpacity>
            </View>
            <Text style={styles.sectionLabel}>GALLERY</Text>
            <Text style={styles.title}>ギャラリー</Text>
            <Text style={styles.bodyText}>{isLoading ? '写真を読み込み中' : loadError ? '写真の読み込みエラー' : `${photos.length} 枚の写真${isSelecting ? ' · 写真をタップして選択' : ''}`}</Text>
            {selectedPhotos.size === 0 && processingIndicator}
            {isLoading && <ActivityIndicator color={colors.green} accessibilityLabel="写真を読み込み中" />}
            {storageError}
          </View>
        }
        ListEmptyComponent={!isLoading && !loadError && photos.length === 0 ? (
          <View style={styles.emptyCard}>
            <View style={styles.emptyIllustration} accessible={false}>
              <View style={styles.emptyLens} />
            </View>
            <Text style={styles.emptyTitle}>まだ写真がありません</Text>
            <Text style={styles.bodyText}>カメラに戻って、残しておきたい学びを撮影しましょう。撮影した写真はここに並びます。</Text>
            <TouchableOpacity style={[styles.button, styles.primaryButton, busy && styles.disabled]}
              accessibilityRole="button" accessibilityLabel="カメラに戻って撮影する"
              accessibilityState={{ disabled: busy }} disabled={busy} onPress={onBack}>
              <Text style={styles.primaryButtonText}>◀ カメラへ</Text>
            </TouchableOpacity>
          </View>
        ) : null}
      />
      {selectedPhotos.size > 0 && (
        <ScrollView style={styles.selectionScroll} contentContainerStyle={styles.selectionPadding}>
          <View style={styles.selectionCard}>
            <Text style={styles.sectionLabel}>SELECTED</Text>
            <Text style={styles.selectionTitle}>{selectedPhotos.size} 枚を選択中</Text>
            <Text style={styles.bodyText}>共有メニューで保存先を選ぶか、ブラウザでダウンロードします。複数枚のダウンロードにはブラウザの許可が必要な場合があります。</Text>
            <TouchableOpacity style={[styles.button, styles.primaryButton, busy && styles.disabled]}
              accessibilityRole="button" accessibilityState={{ disabled: busy }}
              disabled={busy} onPress={handleExport}>
              <Text style={styles.primaryButtonText}>選択した {selectedPhotos.size} 枚を写真に保存</Text>
            </TouchableOpacity>
            <TouchableOpacity style={[styles.button, styles.deleteButton, busy && styles.disabled]}
              accessibilityRole="button" accessibilityState={{ disabled: busy }}
              disabled={busy} onPress={handleDeleteSelected}>
              <Text style={styles.deleteButtonText}>選択した {selectedPhotos.size} 枚を削除</Text>
            </TouchableOpacity>
            {processingIndicator}
          </View>
        </ScrollView>
      )}
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: colors.paper },
  list: { flex: 1 },
  gridContent: { paddingHorizontal: gridPadding, paddingBottom: 16 },
  gridRow: { gap: gridGap, marginBottom: gridGap },
  galleryHeader: { paddingTop: 16, paddingBottom: 20, gap: 8 },
  navigation: { flexDirection: 'row', flexWrap: 'wrap', justifyContent: 'space-between', gap: 8, marginVertical: 8 },
  navButton: { minHeight: 44, minWidth: 44, paddingVertical: 12, paddingHorizontal: 10, justifyContent: 'center' },
  navButtonText: { color: colors.greenDark, fontSize: 15, fontWeight: '600' },
  sectionLabel: { color: colors.green, fontSize: 11, fontWeight: '700', letterSpacing: 2 },
  title: { color: colors.ink, fontSize: 28, fontWeight: '600' },
  bodyText: { color: colors.muted, fontSize: 14, lineHeight: 22 },
  imageContainer: { borderRadius: 10, overflow: 'hidden', backgroundColor: colors.line },
  image: { width: '100%', height: '100%' },
  selectedOverlay: { ...StyleSheet.absoluteFill, backgroundColor: 'rgba(66, 117, 87, 0.38)', borderWidth: 2, borderColor: colors.green, borderRadius: 10, alignItems: 'flex-end', padding: 6 },
  checkCircle: { width: 28, height: 28, borderRadius: 14, backgroundColor: colors.green, alignItems: 'center', justifyContent: 'center' },
  checkmark: { color: colors.white, fontSize: 17, fontWeight: '700' },
  emptyCard: { backgroundColor: colors.white, borderWidth: 1, borderColor: colors.line, borderRadius: 13, padding: 22, gap: 18, marginBottom: 8 },
  emptyIllustration: { width: 64, height: 50, borderRadius: 12, borderWidth: 2, borderColor: colors.green, backgroundColor: colors.tint, alignItems: 'center', justifyContent: 'center' },
  emptyLens: { width: 25, height: 25, borderRadius: 13, borderWidth: 2, borderColor: colors.green },
  emptyTitle: { color: colors.ink, fontSize: 20, fontWeight: '600' },
  button: { minHeight: 48, minWidth: 44, borderRadius: 8, paddingHorizontal: 14, paddingVertical: 13, alignItems: 'center', justifyContent: 'center', borderWidth: 1 },
  primaryButton: { backgroundColor: colors.green, borderColor: colors.green },
  primaryButtonText: { color: colors.white, fontSize: 15, fontWeight: '600', textAlign: 'center' },
  outlineButton: { backgroundColor: colors.white, borderColor: colors.green },
  outlineButtonText: { color: colors.greenDark, fontSize: 15, fontWeight: '600', textAlign: 'center' },
  deleteButton: { backgroundColor: colors.dangerTint, borderColor: colors.dangerTint },
  deleteButtonText: { color: colors.danger, fontSize: 15, fontWeight: '600', textAlign: 'center' },
  disabled: { opacity: 0.5 },
  selectionScroll: { flexGrow: 0, flexShrink: 1, maxHeight: '45%' },
  selectionPadding: { paddingHorizontal: 16, paddingTop: 8, paddingBottom: 12 },
  selectionCard: { borderRadius: 13, borderWidth: 1, borderColor: colors.line, backgroundColor: colors.white, padding: 14, gap: 10 },
  selectionTitle: { color: colors.ink, fontSize: 17, fontWeight: '600' },
  processing: { flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 8, paddingVertical: 4 },
  previewChrome: { flexGrow: 0, flexShrink: 1, maxHeight: '35%' },
  previewHeader: { flexDirection: 'row', flexWrap: 'wrap', alignItems: 'center', justifyContent: 'space-between', gap: 8, paddingHorizontal: 16, paddingVertical: 8 },
  photoCounter: { color: colors.muted, fontSize: 14, paddingHorizontal: 10, paddingVertical: 12 },
  previewFooter: { padding: 16, gap: 10 },
  previewActions: { flexDirection: 'row', flexWrap: 'wrap', gap: 10 },
  previewAction: { flexGrow: 1, flexBasis: 120 },
});
