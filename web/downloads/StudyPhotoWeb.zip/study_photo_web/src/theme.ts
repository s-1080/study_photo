export const colors = {
  paper: '#f7f8f2',
  white: '#ffffff',
  ink: '#222c28',
  muted: '#65716a',
  green: '#427557',
  greenDark: '#30593f',
  line: '#dfe4d9',
  tint: '#eef2e7',
  danger: '#b44339',
  dangerTint: '#fbefec',
  camera: '#17251e',
} as const;
