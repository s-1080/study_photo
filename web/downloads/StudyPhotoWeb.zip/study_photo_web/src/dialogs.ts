type ConfirmOptions = { cancelLabel?: string; confirmLabel?: string; destructive?: boolean };
let pending: Promise<unknown> = Promise.resolve();
let nextId = 0;

function openDialog(title: string, message: string, options: ConfirmOptions, cancellable: boolean): Promise<boolean> {
  const result = pending.then(() => new Promise<boolean>(resolve => {
    const previousFocus = document.activeElement instanceof HTMLElement ? document.activeElement : null;
    const dialog = document.createElement('dialog');
    dialog.className = 'study-dialog';
    const heading = document.createElement('h2');
    heading.id = `study-dialog-${++nextId}`;
    heading.textContent = title;
    dialog.setAttribute('aria-labelledby', heading.id);
    const description = document.createElement('p');
    description.textContent = message;
    const actions = document.createElement('div');
    actions.className = 'study-dialog-actions';
    if (cancellable) {
      const cancel = document.createElement('button');
      cancel.type = 'button';
      cancel.textContent = options.cancelLabel ?? 'キャンセル';
      cancel.className = 'study-dialog-cancel';
      cancel.addEventListener('click', () => dialog.close('cancel'));
      actions.append(cancel);
    }
    const confirm = document.createElement('button');
    confirm.type = 'button';
    confirm.textContent = options.confirmLabel ?? (cancellable ? '削除する' : 'OK');
    confirm.className = options.destructive ? 'study-dialog-danger' : 'study-dialog-confirm';
    confirm.addEventListener('click', () => dialog.close('confirm'));
    actions.append(confirm);
    dialog.append(heading, description, actions);
    dialog.addEventListener('close', () => {
      const accepted = dialog.returnValue === 'confirm';
      dialog.remove();
      if (previousFocus?.isConnected) previousFocus.focus();
      resolve(accepted);
    }, { once: true });
    document.body.append(dialog);
    dialog.showModal();
    (cancellable ? actions.firstElementChild as HTMLButtonElement : confirm).focus();
  }));
  pending = result;
  return result;
}

export function confirmAction(title: string, message: string, options: ConfirmOptions = {}): Promise<boolean> {
  return openDialog(title, message, options, true);
}

export async function showMessage(title: string, message: string): Promise<void> {
  await openDialog(title, message, {}, false);
}
