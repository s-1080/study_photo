import React from 'react';
import { StyleSheet, Text, View } from 'react-native';
import { colors } from './theme';

export default function Brand() {
  return (
    <View style={styles.brand}>
      <View style={styles.cameraIcon} accessibilityElementsHidden>
        <View style={styles.cameraTop} />
        <View style={styles.lens} />
      </View>
      <Text style={styles.name}>StudyPhoto<Text style={styles.dot}>.</Text></Text>
    </View>
  );
}

const styles = StyleSheet.create({
  brand: { flexDirection: 'row', alignItems: 'center', gap: 10 },
  name: { color: colors.ink, fontSize: 23, fontWeight: '700', letterSpacing: -0.8 },
  dot: { color: colors.green },
  cameraIcon: {
    width: 27, height: 23, borderWidth: 2, borderColor: colors.green,
    borderRadius: 6, alignItems: 'center', justifyContent: 'center',
  },
  cameraTop: {
    position: 'absolute', top: -5, width: 11, height: 4,
    backgroundColor: colors.green, borderTopLeftRadius: 2, borderTopRightRadius: 2,
  },
  lens: { width: 11, height: 11, borderWidth: 2, borderColor: colors.green, borderRadius: 6 },
});
