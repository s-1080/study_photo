import React, { useCallback, useEffect, useRef, useState } from 'react';
import {
  ActivityIndicator, Animated, ScrollView,
  StyleSheet, Text, TouchableOpacity, useWindowDimensions, View,
} from 'react-native';
import { deleteAllPhotos, getSavedPhotos, savePhotoToSandbox } from './PhotoManager';
import { SafeAreaView } from 'react-native-safe-area-context';
import Brand from './Brand';
import { colors } from './theme';
import { confirmAction, showMessage } from './dialogs';

type Props = {
  onGoToGallery: () => void;
};

type CameraStatus = 'prompt' | 'requesting' | 'streaming' | 'paused' | 'error';

// Keep camera consent for screen changes, not across a page reload.
let sessionCameraGranted = false;

function errorText(error: unknown): string {
  return typeof error === 'object' && error !== null
    && 'message' in error && typeof error.message === 'string'
    ? error.message : String(error);
}

function cameraErrorText(error: unknown): string {
  const name = typeof error === 'object' && error !== null
    && 'name' in error && typeof error.name === 'string' ? error.name : '';
  switch (name) {
    case 'NotAllowedError':
    case 'PermissionDeniedError':
      return 'カメラへのアクセスが許可されていません。Safariのこのサイトのカメラ設定を「許可」に変更してから、もう一度お試しください。';
    case 'NotFoundError':
    case 'DevicesNotFoundError':
      return '利用できるカメラが見つかりません。カメラを接続した端末で、もう一度お試しください。';
    case 'NotReadableError':
    case 'TrackStartError':
      return 'カメラを開始できません。他のアプリでカメラを使用している場合は終了し、端末のカメラ許可も確認してください。';
    case 'OverconstrainedError':
      return 'このカメラでは撮影設定を利用できません。別のカメラやブラウザーでお試しください。';
    case 'SecurityError':
      return 'このサイトでのカメラ利用がブラウザーに制限されています。HTTPS接続とサイトのカメラ設定を確認してください。';
    case 'AbortError':
      return 'カメラの開始が中断されました。もう一度お試しください。';
    default:
      return `カメラを開始できませんでした。${errorText(error)}`;
  }
}

// Darken lifted shadows slightly and compress highlights without inventing clipped detail.
const toneCurve = Uint8Array.from({ length: 256 }, (_, value) =>
  Math.round(value < 96 ? value * 0.92 : value < 208 ? value - 8 : 200 + (value - 208) * 40 / 47));

function applyTone(canvas: HTMLCanvasElement, context: CanvasRenderingContext2D): void {
  const pixels = context.getImageData(0, 0, canvas.width, canvas.height);
  const data = pixels.data;
  for (let index = 0; index < data.length; index += 4) {
    data[index] = toneCurve[data[index]];
    data[index + 1] = toneCurve[data[index + 1]];
    data[index + 2] = toneCurve[data[index + 2]];
  }
  context.putImageData(pixels, 0, 0);
}

// Edge contrast is lower when the camera moves during exposure.
function edgeEnergy(pixels: ImageData): number {
  const { data, width, height } = pixels;
  let total = 0;
  for (let y = 1; y < height - 1; y += 2) {
    for (let x = 1; x < width - 1; x += 2) {
      const index = (y * width + x) * 4;
      const right = index + 4;
      const down = index + width * 4;
      const center = data[index] * 77 + data[index + 1] * 150 + data[index + 2] * 29;
      const horizontal = center - data[right] * 77 - data[right + 1] * 150 - data[right + 2] * 29;
      const vertical = center - data[down] * 77 - data[down + 1] * 150 - data[down + 2] * 29;
      total += horizontal * horizontal + vertical * vertical;
    }
  }
  return total;
}

function nextVideoFrame(video: HTMLVideoElement): Promise<void> {
  const { promise, resolve } = Promise.withResolvers<void>();
  const timeout = window.setTimeout(resolve, 120);
  video.requestVideoFrameCallback?.(() => {
    window.clearTimeout(timeout);
    resolve();
  });
  return promise;
}

export default function CameraScreen({ onGoToGallery }: Props) {
  const [cameraStatus, setCameraStatus] = useState<CameraStatus>('prompt');
  const [cameraError, setCameraError] = useState('');
  const [operationError, setOperationError] = useState('');
  const [statusMessage, setStatusMessage] = useState('');
  const [savedCount, setSavedCount] = useState<number | null>(null);
  const [isProcessing, setIsProcessing] = useState(false);
  const [isDeleting, setIsDeleting] = useState(false);
  const [isCameraReady, setIsCameraReady] = useState(false);
  const [zoomLevel, setZoomLevel] = useState(1);
  const videoRef = useRef<HTMLVideoElement | null>(null);
  const frameRef = useRef<HTMLDivElement | null>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const mountedRef = useRef(false);
  const requestedRef = useRef(false);
  const grantedRef = useRef(sessionCameraGranted);
  const requestGenerationRef = useRef(0);
  const pendingRequestRef = useRef<number | null>(null);
  const removeTrackListenerRef = useRef<(() => void) | null>(null);
  const operationBusyRef = useRef(false);
  const countGenerationRef = useRef(0);
  const [shutterOpacity] = useState(() => new Animated.Value(0));
  const zoomLabel = `${zoomLevel.toFixed(1)}x`;
  const { height } = useWindowDimensions();
  const compact = height < 700;
  const isBusy = isProcessing || isDeleting;
  const isStarting = cameraStatus === 'requesting'
    || (cameraStatus === 'streaming' && !isCameraReady);

  const stopCamera = useCallback(() => {
    requestGenerationRef.current += 1;
    pendingRequestRef.current = null;
    removeTrackListenerRef.current?.();
    removeTrackListenerRef.current = null;
    const stream = streamRef.current;
    streamRef.current = null;
    stream?.getTracks().forEach((track) => track.stop());
    if (videoRef.current) {
      videoRef.current.pause();
      videoRef.current.srcObject = null;
    }
    if (mountedRef.current) setIsCameraReady(false);
  }, []);

  const failCamera = useCallback((message: string) => {
    stopCamera();
    grantedRef.current = false;
    sessionCameraGranted = false;
    if (!mountedRef.current) return;
    setCameraStatus('error');
    setCameraError(message);
  }, [stopCamera]);

  const attachStream = useCallback((video: HTMLVideoElement, stream: MediaStream) => {
    video.srcObject = stream;
    void video.play().catch((error: unknown) => {
      if (mountedRef.current && streamRef.current === stream) {
        failCamera(`カメラ映像を再生できませんでした。${errorText(error)} 再試行してください。`);
      }
    });
  }, [failCamera]);

  const setVideoElement = useCallback((video: HTMLVideoElement | null) => {
    videoRef.current = video;
    if (video && streamRef.current) attachStream(video, streamRef.current);
  }, [attachStream]);

  const startCamera = useCallback(async () => {
    if (!mountedRef.current || document.visibilityState === 'hidden'
      || pendingRequestRef.current !== null || streamRef.current) return;
    requestedRef.current = true;
    setCameraError('');
    setCameraStatus('requesting');
    setIsCameraReady(false);
    if (!window.isSecureContext) {
      failCamera('カメラはHTTPSの安全な接続でのみ利用できます。HTTPSのStudyPhotoを開いてから、もう一度お試しください。');
      return;
    }
    if (!navigator.mediaDevices?.getUserMedia) {
      failCamera('このブラウザーではカメラを利用できません。Safariなど、カメラに対応したブラウザーで開いてください。');
      return;
    }
    const requestId = ++requestGenerationRef.current;
    pendingRequestRef.current = requestId;
    try {
      const stream = await navigator.mediaDevices.getUserMedia({
        audio: false,
        video: {
          facingMode: { ideal: 'environment' },
          width: { ideal: 4096 },
          height: { ideal: 3072 },
        },
      });
      // Permission can resolve after navigation or after the tab was hidden.
      if (!mountedRef.current || requestId !== requestGenerationRef.current
        || document.hidden) {
        stream.getTracks().forEach((track) => track.stop());
        return;
      }
      const track = stream.getVideoTracks()[0];
      if (!track || track.readyState === 'ended') {
        stream.getTracks().forEach((item) => item.stop());
        failCamera('カメラ映像を取得できませんでした。もう一度お試しください。');
        return;
      }
      streamRef.current = stream;
      grantedRef.current = true;
      sessionCameraGranted = true;
      const handleEnded = () => {
        if (streamRef.current === stream) {
          failCamera('カメラとの接続が終了しました。再開するには、もう一度カメラを許可してください。');
        }
      };
      track.addEventListener('ended', handleEnded);
      removeTrackListenerRef.current = () => track.removeEventListener('ended', handleEnded);
      setCameraStatus('streaming');
      if (videoRef.current) attachStream(videoRef.current, stream);
    } catch (error) {
      if (mountedRef.current && requestId === requestGenerationRef.current
        && !document.hidden) {
        failCamera(cameraErrorText(error));
      }
    } finally {
      if (pendingRequestRef.current === requestId) pendingRequestRef.current = null;
    }
  }, [attachStream, failCamera]);

  const refreshSavedCount = useCallback(async () => {
    const generation = ++countGenerationRef.current;
    try {
      const photos = await getSavedPhotos();
      if (mountedRef.current && generation === countGenerationRef.current) {
        setSavedCount(photos.length);
      }
    } catch (error) {
      if (mountedRef.current && generation === countGenerationRef.current) {
        setSavedCount(null);
        setOperationError(`保存枚数を確認できませんでした。${errorText(error)}`);
      }
    }
  }, []);

  useEffect(() => {
    mountedRef.current = true;
    void refreshSavedCount();
    const suspend = () => {
      stopCamera();
      if (requestedRef.current) {
        setCameraStatus('paused');
        setCameraError('');
      }
    };
    const resume = () => {
      if (document.visibilityState !== 'hidden' && grantedRef.current) {
        void startCamera();
      }
    };
    const handleVisibility = () => {
      if (document.visibilityState === 'hidden') suspend();
      else resume();
    };
    document.addEventListener('visibilitychange', handleVisibility);
    window.addEventListener('pagehide', suspend);
    window.addEventListener('pageshow', resume);
    if (sessionCameraGranted) void startCamera();
    return () => {
      mountedRef.current = false;
      countGenerationRef.current += 1;
      document.removeEventListener('visibilitychange', handleVisibility);
      window.removeEventListener('pagehide', suspend);
      window.removeEventListener('pageshow', resume);
      stopCamera();
      shutterOpacity.stopAnimation();
    };
  }, [refreshSavedCount, shutterOpacity, startCamera, stopCamera]);

  const checkVideoReady = () => {
    const video = videoRef.current;
    const track = streamRef.current?.getVideoTracks()[0];
    if (mountedRef.current && document.visibilityState !== 'hidden' && video
      && video.srcObject === streamRef.current && track?.readyState === 'live'
      && video.readyState >= HTMLMediaElement.HAVE_CURRENT_DATA
      && video.videoWidth > 0 && video.videoHeight > 0) {
      setIsCameraReady(true);
    }
  };

  const flashShutter = () => {
    shutterOpacity.stopAnimation();
    shutterOpacity.setValue(1);
    Animated.sequence([
      Animated.delay(50),
      Animated.timing(shutterOpacity, {
        toValue: 0,
        duration: 150,
        useNativeDriver: false,
      }),
    ]).start();
  };

  const takePicture = async () => {
    const video = videoRef.current;
    const frame = frameRef.current;
    const track = streamRef.current?.getVideoTracks()[0];
    if (operationBusyRef.current || !isCameraReady || !video || !frame
      || track?.readyState !== 'live' || document.visibilityState === 'hidden') return;
    operationBusyRef.current = true;
    setIsProcessing(true);
    setOperationError('');
    setStatusMessage('保存中');
    let temporaryUri: string | null = null;
    try {
      const bounds = frame.getBoundingClientRect();
      if (bounds.width <= 0 || bounds.height <= 0
        || video.readyState < HTMLMediaElement.HAVE_CURRENT_DATA
        || video.videoWidth <= 0 || video.videoHeight <= 0) {
        throw new Error('カメラ映像の準備ができていません。少し待って再試行してください。');
      }
      // object-fit: cover crops first; the centered CSS scale adds digital zoom.
      const aspect = bounds.width / bounds.height;
      let cropWidth = video.videoWidth;
      let cropHeight = video.videoHeight;
      if (cropWidth / cropHeight > aspect) cropWidth = cropHeight * aspect;
      else cropHeight = cropWidth / aspect;
      cropWidth /= zoomLevel;
      cropHeight /= zoomLevel;
      const canvas = document.createElement('canvas');
      canvas.width = Math.max(1, Math.round(cropWidth));
      canvas.height = Math.max(1, Math.round(cropHeight));
      const context = canvas.getContext('2d', { willReadFrequently: true });
      if (!context) throw new Error('このブラウザーでは画像を作成できません。');
      const sampleScale = Math.min(1, 320 / Math.max(cropWidth, cropHeight));
      const sample = document.createElement('canvas');
      sample.width = Math.max(1, Math.round(cropWidth * sampleScale));
      sample.height = Math.max(1, Math.round(cropHeight * sampleScale));
      const sampleContext = sample.getContext('2d', { willReadFrequently: true });
      if (!sampleContext) throw new Error('カメラ映像を解析できませんでした。');
      const sourceX = (video.videoWidth - cropWidth) / 2;
      const sourceY = (video.videoHeight - cropHeight) / 2;
      let bestScore = -1;
      flashShutter();
      // Keep the clearest frame of a short burst; do not blur images together.
      for (let attempt = 0; attempt < 4; attempt += 1) {
        if (attempt > 0) await nextVideoFrame(video);
        if (track.readyState !== 'live' || document.hidden
          || video.readyState < HTMLMediaElement.HAVE_CURRENT_DATA) break;
        sampleContext.drawImage(video, sourceX, sourceY, cropWidth, cropHeight,
          0, 0, sample.width, sample.height);
        const score = edgeEnergy(sampleContext.getImageData(0, 0, sample.width, sample.height));
        if (bestScore < 0 || score > bestScore * 1.025) {
          context.drawImage(video, sourceX, sourceY, cropWidth, cropHeight,
            0, 0, canvas.width, canvas.height);
          bestScore = score;
        }
      }
      if (bestScore < 0) throw new Error('カメラ映像が停止しました。もう一度お試しください。');
      applyTone(canvas, context);
      const { promise, resolve, reject } = Promise.withResolvers<Blob>();
      canvas.toBlob((result) => {
        if (result?.type === 'image/jpeg') resolve(result);
        else reject(new Error('JPEG画像を作成できませんでした。'));
      }, 'image/jpeg', 1);
      const blob = await promise;
      temporaryUri = URL.createObjectURL(blob);
      await savePhotoToSandbox(temporaryUri);
      URL.revokeObjectURL(temporaryUri);
      temporaryUri = null;
      if (mountedRef.current) {
        setStatusMessage('写真を一時保存しました');
        await refreshSavedCount();
      }
    } catch (error) {
      if (mountedRef.current) {
        setStatusMessage('');
        setOperationError(`撮影・保存できませんでした。${errorText(error)}`);
      }
    } finally {
      if (temporaryUri) URL.revokeObjectURL(temporaryUri);
      operationBusyRef.current = false;
      if (mountedRef.current) setIsProcessing(false);
    }
  };

  const handleEndClass = async () => {
    if (operationBusyRef.current) return;
    operationBusyRef.current = true;
    setIsDeleting(true);
    setOperationError('');
    try {
      const confirmed = await confirmAction(
        '授業終了',
        '保存されている全ての一時画像を削除します。よろしいですか？',
        { cancelLabel: 'キャンセル', confirmLabel: '削除する', destructive: true },
      );
      if (!confirmed || !mountedRef.current) return;
      await deleteAllPhotos();
      countGenerationRef.current += 1;
      if (mountedRef.current) {
        setSavedCount(0);
        setStatusMessage('画像データを全て削除しました');
      }
      await showMessage('削除完了', '画像データを全て削除しました。');
    } catch (error) {
      const message = `画像を削除できませんでした。${errorText(error)}`;
      if (mountedRef.current) setOperationError(message);
      await showMessage('削除できませんでした', message);
    } finally {
      operationBusyRef.current = false;
      if (mountedRef.current) setIsDeleting(false);
    }
  };

  const openGallery = () => {
    stopCamera();
    if (requestedRef.current) setCameraStatus('paused');
    onGoToGallery();
  };

  return (
    <SafeAreaView style={styles.container}>
      <View style={[styles.header, compact && styles.headerCompact]}>
        <Brand />
      </View>
      <View style={styles.sectionBar}>
        <TouchableOpacity
          style={[styles.endButton, isBusy && styles.shutterProcessing]}
          onPress={handleEndClass}
          disabled={isBusy}
          accessibilityRole="button"
          accessibilityLabel="授業終了、全ての一時画像を削除"
        >
          <Text style={styles.endButtonText}>授業終了 (全削除)</Text>
        </TouchableOpacity>
      </View>
      <View style={styles.preview}>
        <div ref={frameRef} style={{ position: 'absolute', inset: 0, overflow: 'hidden' }}>
          {(cameraStatus === 'requesting' || cameraStatus === 'streaming') && (
            <video
              ref={setVideoElement}
              autoPlay
              playsInline
              muted
              aria-label="カメラのプレビュー"
              onLoadedMetadata={checkVideoReady}
              onLoadedData={checkVideoReady}
              onCanPlay={checkVideoReady}
              onPlaying={checkVideoReady}
              onError={() => {
                if (streamRef.current) failCamera('カメラ映像を読み込めませんでした。もう一度お試しください。');
              }}
              style={{
                position: 'absolute', inset: 0, width: '100%', height: '100%',
                objectFit: 'cover', objectPosition: 'center',
                transform: `scale(${zoomLevel})`, transformOrigin: 'center',
                filter: 'brightness(0.94) contrast(1.02)', pointerEvents: 'none',
              }}
            />
          )}
        </div>
        {!isCameraReady && (
          <ScrollView style={styles.permissionScroll} contentContainerStyle={styles.permissionContent}>
            <View style={[styles.permissionCard, compact && styles.permissionCardCompact]}>
              {isStarting ? (
                <>
                  <ActivityIndicator color={colors.green} />
                  <Text style={styles.permissionTitle}>カメラを準備中</Text>
                </>
              ) : (
                <>
                  <Text style={styles.permissionTitle}>
                    {cameraStatus === 'error' ? 'カメラを利用できません'
                      : cameraStatus === 'paused' ? 'カメラを停止しました' : '授業の記録をすぐに'}
                  </Text>
                  <Text style={styles.permissionText} accessibilityRole={cameraError ? 'alert' : undefined}>
                    {cameraError || (cameraStatus === 'paused'
                      ? 'カメラを再開してください。'
                      : '撮影にはカメラの許可が必要です。')}
                  </Text>
                  {cameraStatus === 'error' && (
                    <Text style={styles.permissionText}>
                      Safariではページメニューの「Webサイトの設定」で、このサイトの「カメラ」を「許可」に変更できます。
                    </Text>
                  )}
                  <TouchableOpacity
                    style={styles.permissionButton}
                    onPress={() => { void startCamera(); }}
                    accessibilityRole="button"
                    accessibilityLabel={cameraStatus === 'prompt' ? 'カメラへのアクセスを許可する' : 'カメラを再試行する'}
                  >
                    <Text style={styles.permissionButtonText}>
                      {cameraStatus === 'prompt' ? 'カメラを許可する'
                        : cameraStatus === 'paused' ? 'カメラを再開する' : 'もう一度試す'}
                    </Text>
                  </TouchableOpacity>
                </>
              )}
            </View>
          </ScrollView>
        )}
        <Animated.View
          pointerEvents="none"
          style={[styles.shutterFlash, { opacity: shutterOpacity }]}
        />
      </View>
      <View style={[styles.dock, compact && styles.dockCompact]}>
        <View>
          <Text style={styles.zoomText}>{zoomLabel}</Text>
          <input
            type="range"
            min={1}
            max={7}
            step={0.1}
            value={zoomLevel}
            onChange={(event) => setZoomLevel(Number(event.currentTarget.value))}
            disabled={!isCameraReady || isBusy}
            aria-label="撮影倍率（デジタル）"
            aria-valuetext={`${zoomLabel}、デジタルズーム`}
            style={{ width: '100%', height: 44, margin: 0, accentColor: colors.green }}
          />
        </View>
        <View style={styles.bottomBar}>
          <View style={styles.controlSlot} />
          <View style={styles.controlSlot}>
            <TouchableOpacity
              style={[styles.shutterButton, (!isCameraReady || isBusy) && styles.shutterProcessing]}
              onPress={takePicture}
              disabled={!isCameraReady || isBusy}
              accessibilityRole="button"
              accessibilityLabel="写真を撮影"
              accessibilityState={{ disabled: !isCameraReady || isBusy, busy: isBusy }}
            >
              <View style={styles.shutterInner} />
            </TouchableOpacity>
          </View>
          <View style={styles.controlSlot}>
            <TouchableOpacity
              style={[styles.galleryButton, isBusy && styles.shutterProcessing]}
              onPress={openGallery}
              disabled={isBusy}
              accessibilityRole="button"
              accessibilityLabel="ギャラリーを開く"
            >
              <View style={styles.galleryIcon} accessibilityElementsHidden>
                <View style={styles.galleryIconLine} />
                <View style={styles.galleryIconLine} />
              </View>
              <Text style={styles.galleryButtonText}>ギャラリー</Text>
            </TouchableOpacity>
          </View>
        </View>
        <Text style={styles.dockNote} accessibilityLiveRegion="polite">
          保存済み {savedCount ?? '—'}枚{statusMessage ? ` · ${statusMessage}` : ''}
        </Text>
        {!!operationError && (
          <Text style={styles.operationError} accessibilityRole="alert">{operationError}</Text>
        )}
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, minHeight: 0, backgroundColor: colors.paper },
  header: { paddingHorizontal: 20, paddingTop: 16, paddingBottom: 8, gap: 6 },
  headerCompact: { paddingTop: 8, paddingBottom: 4 },
  sectionBar: {
    flexDirection: 'row', alignItems: 'center', justifyContent: 'flex-end',
    paddingHorizontal: 20, paddingBottom: 6,
  },
  endButton: {
    minHeight: 44, justifyContent: 'center', paddingHorizontal: 12,
    backgroundColor: colors.dangerTint, borderRadius: 7,
  },
  endButtonText: { color: colors.danger, fontSize: 12, fontWeight: '600' },
  preview: {
    flex: 1, minHeight: 0, marginHorizontal: 16, borderRadius: 13,
    overflow: 'hidden', backgroundColor: colors.camera,
    borderWidth: 1, borderColor: colors.line,
  },
  shutterFlash: { ...StyleSheet.absoluteFill, backgroundColor: colors.white },
  dock: { paddingHorizontal: 16, paddingTop: 10, paddingBottom: 10, gap: 8 },
  dockCompact: { paddingTop: 6, paddingBottom: 4, gap: 4 },
  zoomText: { color: colors.greenDark, fontSize: 14, fontWeight: '600', textAlign: 'right' },
  bottomBar: { flexDirection: 'row', alignItems: 'center' },
  controlSlot: { flex: 1, alignItems: 'center' },
  shutterButton: {
    width: 72, height: 72, borderRadius: 36, backgroundColor: colors.tint,
    borderWidth: 2, borderColor: colors.green, alignItems: 'center', justifyContent: 'center',
  },
  shutterProcessing: { opacity: 0.5 },
  shutterInner: {
    width: 56, height: 56, borderRadius: 28, backgroundColor: colors.white,
    borderWidth: 1, borderColor: colors.line,
  },
  galleryButton: {
    minHeight: 60, minWidth: 76, paddingHorizontal: 4,
    alignItems: 'center', justifyContent: 'center', gap: 5,
  },
  galleryIcon: {
    width: 27, height: 23, borderWidth: 1.5, borderColor: colors.green,
    borderRadius: 5, padding: 5, justifyContent: 'space-between',
  },
  galleryIconLine: { height: 2, backgroundColor: colors.green, borderRadius: 1 },
  galleryButtonText: { color: colors.greenDark, fontSize: 11, fontWeight: '600' },
  dockNote: { color: colors.muted, fontSize: 10, lineHeight: 15, textAlign: 'center' },
  operationError: { color: colors.danger, fontSize: 11, lineHeight: 16, textAlign: 'center' },
  permissionScroll: { flex: 1, backgroundColor: colors.paper },
  permissionContent: { flexGrow: 1, justifyContent: 'center', padding: 20 },
  permissionCard: {
    backgroundColor: colors.white, borderWidth: 1, borderColor: colors.line,
    borderRadius: 13, padding: 24, gap: 16,
  },
  permissionCardCompact: { padding: 16, gap: 12 },
  permissionTitle: { color: colors.ink, fontSize: 21, lineHeight: 30, fontWeight: '600' },
  permissionText: { color: colors.muted, fontSize: 14, lineHeight: 23 },
  permissionButton: {
    minHeight: 48, borderRadius: 7, backgroundColor: colors.green,
    alignItems: 'center', justifyContent: 'center', paddingHorizontal: 16,
  },
  permissionButtonText: { color: colors.white, fontSize: 14, fontWeight: '600' },
});
