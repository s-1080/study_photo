type StoredPhoto = { id: number; createdAt: number; blob: Blob };
type CachedPhoto = StoredPhoto & { uri: string };

const DATABASE = 'studyphoto-gallery';
const STORE = 'photos';
const cache = new Map<number, CachedPhoto>();
const photosByUri = new Map<string, CachedPhoto>();
let databasePromise: Promise<IDBDatabase> | null = null;

function forgetPhoto(photo: CachedPhoto): void {
  URL.revokeObjectURL(photo.uri);
  cache.delete(photo.id);
  photosByUri.delete(photo.uri);
}

function clearCache(): void {
  for (const photo of cache.values()) forgetPhoto(photo);
}

if (typeof window !== 'undefined') {
  window.addEventListener('pagehide', (event) => {
    if (!event.persisted) clearCache();
  });
}

function openDatabase(): Promise<IDBDatabase> {
  if (databasePromise) return databasePromise;
  if (typeof indexedDB === 'undefined') {
    return Promise.reject(new Error('このブラウザでは写真の保存に必要な IndexedDB が利用できません。'));
  }
  const { promise: opening, resolve, reject } = Promise.withResolvers<IDBDatabase>();
  const request = indexedDB.open(DATABASE, 1);
  let failed = false;
  request.onupgradeneeded = () => {
    request.result.createObjectStore(STORE, { keyPath: 'id', autoIncrement: true });
  };
  request.onerror = () => { failed = true; reject(request.error); };
  request.onblocked = () => {
    failed = true;
    reject(new Error('写真の保存領域を開けません。ほかの StudyPhoto タブを閉じて再試行してください。'));
  };
  request.onsuccess = () => {
    const database = request.result;
    if (failed) { database.close(); return; }
    database.onversionchange = () => {
      database.close();
      databasePromise = null;
      clearCache();
    };
    resolve(database);
  };
  databasePromise = opening;
  void opening.catch(() => { if (databasePromise === opening) databasePromise = null; });
  return opening;
}

// A request succeeding is not a durable write: resolve only after the transaction commits.
function transact<T>(
  database: IDBDatabase,
  mode: IDBTransactionMode,
  work: (store: IDBObjectStore, result: (value: T) => void, abort: (error: Error) => void) => void,
): Promise<T> {
  const { promise, resolve, reject } = Promise.withResolvers<T>();
  const transaction = database.transaction(STORE, mode);
  let value: T;
  let failure: Error | null = null;
  transaction.oncomplete = () => resolve(value);
  transaction.onabort = () => reject(failure ?? transaction.error ?? new Error('写真の保存処理が中断されました。'));
  const abort = (error: Error) => { failure = error; transaction.abort(); };
  try {
    work(transaction.objectStore(STORE), (result) => { value = result; }, abort);
  } catch (error) {
    abort(error instanceof Error ? error : new Error(String(error)));
  }
  return promise;
}

function cachePhoto(photo: StoredPhoto): CachedPhoto {
  const existing = cache.get(photo.id);
  if (existing) return existing;
  const entry = { ...photo, uri: URL.createObjectURL(photo.blob) };
  cache.set(photo.id, entry);
  photosByUri.set(entry.uri, entry);
  return entry;
}

function storedPhoto(uri: string): CachedPhoto {
  const photo = photosByUri.get(uri);
  if (!photo) throw new Error('この写真はアプリ内の保存済み写真ではありません。ギャラリーを再読み込みしてください。');
  return photo;
}

export async function hasExistingPhotos(): Promise<boolean> {
  const database = await openDatabase();
  return transact<boolean>(database, 'readonly', (store, result) => {
    const request = store.count();
    request.onsuccess = () => result(request.result > 0);
  });
}

export async function getSavedPhotos(): Promise<string[]> {
  const database = await openDatabase();
  const photos = await transact<StoredPhoto[]>(database, 'readonly', (store, result) => {
    const request = store.getAll();
    request.onsuccess = () => result(request.result as StoredPhoto[]);
  });
  const ids = new Set(photos.map((photo) => photo.id));
  for (const photo of cache.values()) {
    if (!ids.has(photo.id)) forgetPhoto(photo);
  }
  // Auto-incremented IDs provide a stable oldest-first order, including equal timestamps.
  return photos.map((photo) => cachePhoto(photo).uri);
}

function imageBlob(blob: Blob, type: 'image/jpeg' | 'image/png'): Promise<Blob> {
  const { promise, resolve, reject } = Promise.withResolvers<Blob>();
  const uri = URL.createObjectURL(blob);
  const image = new Image();
  image.onerror = () => {
    URL.revokeObjectURL(uri);
    reject(new Error('画像を読み込めませんでした。'));
  };
  image.onload = () => {
    URL.revokeObjectURL(uri);
    try {
      const canvas = document.createElement('canvas');
      canvas.width = image.naturalWidth;
      canvas.height = image.naturalHeight;
      const context = canvas.getContext('2d');
      if (!context || !canvas.width || !canvas.height) throw new Error('画像を変換できませんでした。');
      if (type === 'image/jpeg') {
        context.fillStyle = '#fff';
        context.fillRect(0, 0, canvas.width, canvas.height);
      }
      context.drawImage(image, 0, 0);
      canvas.toBlob((converted) => {
        if (converted) resolve(converted);
        else reject(new Error('画像の変換に失敗しました。'));
        canvas.width = 0;
        canvas.height = 0;
      }, type, type === 'image/jpeg' ? 0.92 : undefined);
    } catch (error) { reject(error); }
  };
  image.src = uri;
  return promise;
}

export async function savePhotoToSandbox(uri: string): Promise<string> {
  if (!uri.startsWith('blob:') && !uri.startsWith('data:image/')) {
    throw new Error('保存できるのはブラウザ内で撮影した画像だけです。');
  }
  const response = await fetch(uri);
  if (!response.ok) throw new Error('撮影した画像を読み込めませんでした。');
  const source = await response.blob();
  if (!source.size) throw new Error('撮影した画像が空です。');
  const blob = source.type === 'image/jpeg' ? source : await imageBlob(source, 'image/jpeg');
  const database = await openDatabase();
  const createdAt = Date.now();
  const id = await transact<number>(database, 'readwrite', (store, result) => {
    const request = store.add({ createdAt, blob });
    request.onsuccess = () => result(request.result as number);
  });
  return cachePhoto({ id, createdAt, blob }).uri;
}

export async function deleteAllPhotos(): Promise<void> {
  const database = await openDatabase();
  await transact<void>(database, 'readwrite', (store, result) => {
    store.clear();
    result(undefined);
  });
  clearCache();
}

export async function deleteSelectedPhotos(uris: string[]): Promise<void> {
  const photos = Array.from(new Set(uris), storedPhoto);
  if (!photos.length) return;
  const database = await openDatabase();
  await transact<void>(database, 'readwrite', (store, result, abort) => {
    let remaining = photos.length;
    for (const photo of photos) {
      const request = store.getKey(photo.id);
      request.onsuccess = () => {
        if (request.result === undefined) {
          abort(new Error('選択した写真はすでに削除されています。ギャラリーを再読み込みしてください。'));
          return;
        }
        remaining -= 1;
        if (remaining === 0) {
          for (const selected of photos) store.delete(selected.id);
          result(undefined);
        }
      };
    }
  });
  for (const photo of photos) forgetPhoto(photo);
}

export async function copyPhotoToClipboard(uri: string): Promise<void> {
  const photo = storedPhoto(uri);
  if (!navigator.clipboard?.write || typeof ClipboardItem === 'undefined') {
    throw new Error('このブラウザでは画像のコピーが利用できません。写真に保存から共有またはダウンロードしてください。');
  }
  const png = imageBlob(photo.blob, 'image/png');
  // Safari requires write() in the original click, before image conversion awaits.
  void png.catch(() => {});
  await navigator.clipboard.write([new ClipboardItem({ 'image/png': png })]);
}

export async function exportPhotos(uris: string[]): Promise<'shared' | 'downloaded' | 'cancelled'> {
  const photos = Array.from(new Set(uris), storedPhoto);
  if (!photos.length) throw new Error('保存する写真を選択してください。');
  const files = photos.map((photo) => new File([photo.blob],
    `StudyPhoto_${photo.createdAt}_${photo.id}.jpg`, { type: 'image/jpeg' }));
  // Do not await storage or conversion here: Safari needs share() during the click.
  if (navigator.share && navigator.canShare?.({ files })) {
    try {
      await navigator.share({ files });
      return 'shared';
    } catch (error) {
      if (error instanceof DOMException && error.name === 'AbortError') return 'cancelled';
      throw error;
    }
  }
  for (let index = 0; index < photos.length; index += 1) {
    const link = document.createElement('a');
    // Export URLs are independent of gallery deletion while the download starts.
    const downloadUri = URL.createObjectURL(files[index]);
    link.href = downloadUri;
    link.download = files[index].name;
    link.style.display = 'none';
    document.body.appendChild(link);
    link.click();
    link.remove();
    window.setTimeout(() => URL.revokeObjectURL(downloadUri), 60_000);
  }
  return 'downloaded';
}
