import { StatusBar } from 'expo-status-bar';
import React, { useState, useEffect } from 'react';
import { StyleSheet, View, Text, ActivityIndicator, TouchableOpacity } from 'react-native';
import { SafeAreaProvider, SafeAreaView, initialWindowMetrics } from 'react-native-safe-area-context';
import CameraScreen from './src/CameraScreen';
import GalleryScreen from './src/GalleryScreen';
import { hasExistingPhotos, deleteAllPhotos } from './src/PhotoManager';
import Brand from './src/Brand';
import { colors } from './src/theme';
import { confirmAction } from './src/dialogs';
import './src/web.css';

type Screen = 'camera' | 'gallery';

export default function App() {
  const [currentScreen, setCurrentScreen] = useState<Screen>('camera');
  const [isReady, setIsReady] = useState(false);
  const [startupError, setStartupError] = useState<string | null>(null);

  useEffect(() => {
    document.title = 'StudyPhoto — 授業の写真をすっきり';
    document.documentElement.lang = 'ja';
    void checkExistingData();
  }, []);

  const checkExistingData = async () => {
    setStartupError(null);
    try {
      if (await hasExistingPhotos()) {
        const shouldDelete = await confirmAction(
          '前回の画像が残っています',
          '前回の授業の画像が残っています。削除して新しく始めますか？',
          { cancelLabel: 'そのまま残す', confirmLabel: '削除して始める', destructive: true },
        );
        if (shouldDelete) await deleteAllPhotos();
      }
      setIsReady(true);
    } catch (error) {
      setStartupError(error instanceof Error ? error.message : '一時保存領域を開けませんでした。');
    }
  };

  return (
    <div className="app-frame">
    <SafeAreaProvider initialMetrics={initialWindowMetrics}>
      <View style={styles.container}>
        <StatusBar style="dark" />
        {!isReady ? (
          <SafeAreaView style={styles.loading}>
            <Brand />
            <View style={styles.loadingCard}>
              {startupError ? (
                <>
                  <Text style={styles.loadingTitle}>保存領域を開けません</Text>
                  <Text style={styles.loadingText}>{startupError} Safariの通常タブで開き直すか、端末の空き容量を確認してください。</Text>
                  <TouchableOpacity accessibilityRole="button" onPress={() => void checkExistingData()} style={{ padding: 14, backgroundColor: colors.green, borderRadius: 7 }}>
                    <Text style={{ color: colors.white }}>もう一度確認する</Text>
                  </TouchableOpacity>
                </>
              ) : (
                <>
                  <ActivityIndicator color={colors.green} />
                  <Text style={styles.loadingTitle}>授業の準備中</Text>
                  <Text style={styles.loadingText}>一時保存した写真を確認しています。</Text>
                </>
              )}
            </View>
          </SafeAreaView>
        ) : currentScreen === 'camera' ? (
          <CameraScreen onGoToGallery={() => setCurrentScreen('gallery')} />
        ) : (
          <GalleryScreen onBack={() => setCurrentScreen('camera')} />
        )}
      </View>
    </SafeAreaProvider>
    </div>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.paper,
  },
  loading: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    paddingHorizontal: 24,
    gap: 28,
  },
  loadingCard: {
    alignSelf: 'stretch',
    alignItems: 'center',
    padding: 24,
    gap: 12,
    backgroundColor: colors.white,
    borderWidth: 1,
    borderColor: colors.line,
    borderRadius: 13,
  },
  loadingTitle: {
    color: colors.ink,
    fontSize: 18,
    fontWeight: '600',
  },
  loadingText: {
    color: colors.muted,
    fontSize: 14,
    textAlign: 'center',
    lineHeight: 21,
  },
});
