import { execFileSync } from 'node:child_process';
import { readFileSync } from 'node:fs';

const repository = 's-1080/study_photo';
const endpoint = `repos/${repository}`;
const branch = 'gh-pages';
const files = ['index.html', 'styles.css', 'site.js', 'vendor/qrcode.mjs', 'downloads/StudyPhoto.zip', '.nojekyll'];
const assets = files.map(path => ({
  path,
  content: readFileSync(new URL(`../site/${path}`, import.meta.url)),
}));

function github(path, method = 'GET', payload) {
  const args = ['api', path, '--method', method];
  if (payload !== undefined) args.push('--input', '-');
  const output = execFileSync('gh', args, {
    input: payload === undefined ? undefined : JSON.stringify(payload),
    encoding: 'utf8',
  }).trim();
  return output ? JSON.parse(output) : null;
}

const pages = github(`${endpoint}/pages`);
if (pages.build_type !== 'legacy' || pages.source?.branch !== branch || pages.source?.path !== '/' || !pages.https_enforced) {
  throw new Error('GitHub Pages must publish the gh-pages root with HTTPS; its configuration was left unchanged.');
}
const previous = github(`${endpoint}/git/matching-refs/heads/${branch}`)
  .find(reference => reference.ref === `refs/heads/${branch}`);
const tree = github(`${endpoint}/git/trees`, 'POST', {
  tree: assets.map(({ path, content }) => ({
    path,
    mode: '100644',
    type: 'blob',
    sha: github(`${endpoint}/git/blobs`, 'POST', {
      content: content.toString('base64'),
      encoding: 'base64',
    }).sha,
  })),
});
const commit = github(`${endpoint}/git/commits`, 'POST', {
  message: 'Publish StudyPhoto site',
  tree: tree.sha,
  parents: previous ? [previous.object.sha] : [],
});
if (previous) {
  github(`${endpoint}/git/refs/heads/${branch}`, 'PATCH', { sha: commit.sha, force: false });
} else {
  github(`${endpoint}/git/refs`, 'POST', { ref: `refs/heads/${branch}`, sha: commit.sha });
}
console.log(`Publication commit: ${commit.sha}`);
console.log(`Site URL: ${pages.html_url}`);
console.log('GitHub Pages deployment is queued. Check the public URL after the build completes.');
