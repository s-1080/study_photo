import { spawn } from 'node:child_process';
import { mkdtempSync, rmSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { fileURLToPath } from 'node:url';

// Expo SDK 57 reads this shell-only setting before loading project .env files.
// A fresh Expo home avoids borrowing the distributor's account or signing cache.
const expoHome = mkdtempSync(join(tmpdir(), 'studyphoto-expo-'));
const server = spawn(process.execPath, [
  fileURLToPath(new URL('../node_modules/expo/bin/cli', import.meta.url)),
  'start', '--tunnel', '--go', ...process.argv.slice(2),
], {
  cwd: fileURLToPath(new URL('../', import.meta.url)),
  env: {
    ...process.env,
    __UNSAFE_EXPO_HOME_DIRECTORY: expoHome,
    EXPO_TOKEN: '',
  },
  stdio: 'inherit',
});

process.once('SIGINT', () => server.kill('SIGINT'));
process.once('SIGTERM', () => server.kill('SIGTERM'));
process.once('exit', () => rmSync(expoHome, { recursive: true, force: true }));
server.once('error', error => {
  console.error(error.message);
  process.exitCode = 1;
});
server.once('exit', (code, signal) => {
  process.exitCode = code ?? (signal === 'SIGINT' ? 130 : 1);
});
