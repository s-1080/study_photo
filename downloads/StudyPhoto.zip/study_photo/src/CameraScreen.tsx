import React, { useEffect, useRef, useState } from 'react';
import {
  ActivityIndicator, Alert, Animated, AppState, Linking, ScrollView,
  StyleSheet, Text, TouchableOpacity, useWindowDimensions, View,
} from 'react-native';
import { CameraView, useCameraPermissions } from 'expo-camera';
import { savePhotoToSandbox, deleteAllPhotos } from './PhotoManager';
import { SafeAreaView } from 'react-native-safe-area-context';
import Slider from '@react-native-community/slider';
import Brand from './Brand';
import { colors } from './theme';

type Props = {
  onGoToGallery: () => void;
};

export default function CameraScreen({ onGoToGallery }: Props) {
  const [permission, requestPermission, getPermission] = useCameraPermissions();
  const cameraRef = useRef<CameraView>(null);
  const [isProcessing, setIsProcessing] = useState(false);
  const [isCameraReady, setIsCameraReady] = useState(false);
  const [zoomLevel, setZoomLevel] = useState(1);
  const zoomLabel = `${zoomLevel.toFixed(1)}x`;
  const shutterOpacity = useRef(new Animated.Value(0)).current;
  const { height } = useWindowDimensions();
  const compact = height < 700;

  useEffect(() => {
    const subscription = AppState.addEventListener('change', (state) => {
      if (state === 'active') {
        void getPermission();
      }
    });
    return () => subscription.remove();
  }, [getPermission]);

  useEffect(() => {
    if (!permission?.granted) setIsCameraReady(false);
  }, [permission?.granted]);

  const openSettings = async () => {
    try {
      await Linking.openSettings();
    } catch (e) {
      console.error('Failed to open Settings', e);
      Alert.alert('設定を開けませんでした', 'iPhoneの「設定」からExpo Go（専用ビルドではStudyPhoto）のカメラを許可してください。');
    }
  };

  const flashShutter = () => {
    shutterOpacity.stopAnimation();
    shutterOpacity.setValue(1);
    Animated.sequence([
      Animated.delay(50),
      Animated.timing(shutterOpacity, {
        toValue: 0,
        duration: 150,
        useNativeDriver: true,
      }),
    ]).start();
  };

  const takePicture = async () => {
    if (cameraRef.current && isCameraReady && !isProcessing) {
      setIsProcessing(true);
      flashShutter();
      try {
        const photo = await cameraRef.current.takePictureAsync({
          quality: 1,
          shutterSound: false,
        });
        if (photo) {
          await savePhotoToSandbox(photo.uri);
        }
      } catch (e) {
        console.error('Failed to take picture', e);
      } finally {
        setIsProcessing(false);
      }
    }
  };

  const handleEndClass = () => {
    Alert.alert(
      "授業終了",
      "保存されている全ての一時画像を削除します。よろしいですか？",
      [
        { text: "キャンセル", style: "cancel" },
        { 
          text: "削除する", 
          style: "destructive",
          onPress: async () => {
            await deleteAllPhotos();
            Alert.alert("削除完了", "画像データを全て削除しました！");
          }
        }
      ]
    );
  };

  return (
    <SafeAreaView style={styles.container}>
      <View style={[styles.header, compact && styles.headerCompact]}>
        <Brand />
        <Text style={styles.subtitle}>授業の写真を、必要なときだけ。</Text>
      </View>
      {permission?.granted ? (
        <>
          <View style={styles.sectionBar}>
            <Text style={styles.sectionLabel}>{isCameraReady ? 'CAMERA' : 'カメラを準備中'}</Text>
            <TouchableOpacity
              style={styles.endButton}
              onPress={handleEndClass}
              accessibilityRole="button"
              accessibilityLabel="授業終了、全ての一時画像を削除"
            >
              <Text style={styles.endButtonText}>授業終了 (全削除)</Text>
            </TouchableOpacity>
          </View>
          <View style={styles.preview}>
            <CameraView
              style={styles.camera}
              facing="back"
              ref={cameraRef}
              zoom={((zoomLevel - 1) / 3) * 0.55}
              pictureSize="Photo"
              onCameraReady={() => setIsCameraReady(true)}
              animateShutter={false}
            />
            <Animated.View
              pointerEvents="none"
              style={[styles.shutterFlash, { opacity: shutterOpacity }]}
            />
          </View>
          <View style={[styles.dock, compact && styles.dockCompact]}>
            <View style={styles.zoomControl}>
              <View style={styles.zoomHeader}>
                <Text style={styles.zoomHint}>倍率（目安）</Text>
                <Text style={styles.zoomText}>{zoomLabel}</Text>
              </View>
              <Slider
                style={styles.zoomSlider}
                minimumValue={1}
                maximumValue={4}
                value={zoomLevel}
                step={0}
                tapToSeek={false}
                onValueChange={setZoomLevel}
                disabled={!isCameraReady || isProcessing}
                minimumTrackTintColor={colors.green}
                maximumTrackTintColor={colors.line}
                accessibilityRole="adjustable"
                accessibilityLabel="撮影倍率"
                accessibilityHint="つまみを左右にスワイプして倍率を調整します"
                accessibilityValue={{ min: 1, max: 4, now: zoomLevel, text: `${zoomLabel}、目安` }}
                accessibilityState={{ disabled: !isCameraReady || isProcessing }}
              />
              <View style={styles.zoomRange}>
                <Text style={styles.zoomHint}>1.0x</Text>
                <Text style={styles.zoomHint}>左右にスワイプして調整</Text>
                <Text style={styles.zoomHint}>4.0x</Text>
              </View>
            </View>
            <View style={styles.bottomBar}>
              <View style={styles.controlSlot} />
              <View style={styles.controlSlot}>
                <TouchableOpacity
                  style={[styles.shutterButton, (!isCameraReady || isProcessing) && styles.shutterProcessing]}
                  onPress={takePicture}
                  disabled={!isCameraReady || isProcessing}
                  accessibilityRole="button"
                  accessibilityLabel="写真を撮影"
                  accessibilityState={{ disabled: !isCameraReady || isProcessing, busy: !isCameraReady || isProcessing }}
                >
                  <View style={styles.shutterInner} />
                </TouchableOpacity>
              </View>
              <View style={styles.controlSlot}>
                <TouchableOpacity
                  style={styles.galleryButton}
                  onPress={onGoToGallery}
                  accessibilityRole="button"
                  accessibilityLabel="ギャラリーを開く"
                >
                  <View style={styles.galleryIcon} accessibilityElementsHidden>
                    <View style={styles.galleryIconLine} />
                    <View style={styles.galleryIconLine} />
                  </View>
                  <Text style={styles.galleryButtonText}>ギャラリー</Text>
                </TouchableOpacity>
              </View>
            </View>
            <Text style={styles.dockNote}>写真はアプリ内に一時保存されます</Text>
          </View>
        </>
      ) : (
        <ScrollView contentContainerStyle={styles.permissionContent}>
          <View style={styles.permissionCard}>
            <Text style={styles.sectionLabel}>READY FOR CLASS</Text>
            {!permission ? (
              <>
                <ActivityIndicator color={colors.green} />
                <Text style={styles.permissionTitle}>カメラを準備中</Text>
                <Text style={styles.permissionText}>カメラへのアクセスを確認しています。</Text>
              </>
            ) : (
              <>
                <Text style={styles.permissionTitle}>授業の記録を、すぐに。</Text>
                <Text style={styles.permissionText}>カメラへのアクセスを許可してください。</Text>
                {!permission.canAskAgain && (
                  <Text style={styles.permissionText}>
                    iPhoneの「設定」でExpo Go（専用ビルドではStudyPhoto）の「カメラ」をオンにすると撮影できます。
                  </Text>
                )}
                <TouchableOpacity
                  style={styles.permissionButton}
                  onPress={permission.canAskAgain ? requestPermission : openSettings}
                  accessibilityRole="button"
                  accessibilityLabel={permission.canAskAgain ? 'カメラへのアクセスを許可する' : 'iPhoneの設定を開く'}
                >
                  <Text style={styles.permissionButtonText}>
                    {permission.canAskAgain ? '許可する' : '設定を開く'}
                  </Text>
                </TouchableOpacity>
              </>
            )}
            <View style={styles.temporaryNote}>
              <Text style={styles.permissionText}>
                写真はアプリ内に一時保存されます。必要な写真を保存したら、授業終了時に全削除できます。
              </Text>
            </View>
            <TouchableOpacity
              style={styles.permissionGalleryButton}
              onPress={onGoToGallery}
              accessibilityRole="button"
              accessibilityLabel="ギャラリーを開く"
            >
              <Text style={styles.permissionGalleryText}>ギャラリーを開く</Text>
            </TouchableOpacity>
          </View>
        </ScrollView>
      )}
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: colors.paper },
  header: { paddingHorizontal: 20, paddingTop: 16, paddingBottom: 8, gap: 6 },
  headerCompact: { paddingTop: 8, paddingBottom: 4 },
  subtitle: { color: colors.muted, fontSize: 12, lineHeight: 18 },
  sectionBar: {
    flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between',
    paddingHorizontal: 20, paddingBottom: 6, gap: 8,
  },
  sectionLabel: { color: colors.muted, fontSize: 10, fontWeight: '600', letterSpacing: 1.8 },
  endButton: {
    minHeight: 44, justifyContent: 'center', paddingHorizontal: 12,
    backgroundColor: colors.dangerTint, borderRadius: 7,
  },
  endButtonText: { color: colors.danger, fontSize: 12, fontWeight: '600' },
  preview: {
    flex: 1, minHeight: 0, marginHorizontal: 16, borderRadius: 13,
    overflow: 'hidden', backgroundColor: colors.camera,
    borderWidth: 1, borderColor: colors.line,
  },
  camera: { flex: 1 },
  shutterFlash: { ...StyleSheet.absoluteFill, backgroundColor: colors.white },
  dock: { paddingHorizontal: 16, paddingTop: 10, paddingBottom: 10, gap: 8 },
  dockCompact: { paddingTop: 6, paddingBottom: 4, gap: 4 },
  zoomControl: {
    paddingHorizontal: 12, paddingVertical: 6, borderRadius: 12,
    backgroundColor: colors.tint, borderWidth: 1, borderColor: colors.line,
  },
  zoomHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', gap: 8 },
  zoomSlider: { width: '100%', height: 44 },
  zoomRange: { flexDirection: 'row', flexWrap: 'wrap', justifyContent: 'space-between', gap: 4 },
  zoomHint: { color: colors.muted, fontSize: 10, lineHeight: 15 },
  zoomText: { color: colors.greenDark, fontSize: 14, fontWeight: '600' },
  bottomBar: { flexDirection: 'row', alignItems: 'center' },
  controlSlot: { flex: 1, alignItems: 'center' },
  shutterButton: {
    width: 72, height: 72, borderRadius: 36, backgroundColor: colors.tint,
    borderWidth: 2, borderColor: colors.green, alignItems: 'center', justifyContent: 'center',
  },
  shutterProcessing: { opacity: 0.5 },
  shutterInner: {
    width: 56, height: 56, borderRadius: 28, backgroundColor: colors.white,
    borderWidth: 1, borderColor: colors.line,
  },
  galleryButton: {
    minHeight: 60, minWidth: 76, paddingHorizontal: 4,
    alignItems: 'center', justifyContent: 'center', gap: 5,
  },
  galleryIcon: {
    width: 27, height: 23, borderWidth: 1.5, borderColor: colors.green,
    borderRadius: 5, padding: 5, justifyContent: 'space-between',
  },
  galleryIconLine: { height: 2, backgroundColor: colors.green, borderRadius: 1 },
  galleryButtonText: { color: colors.greenDark, fontSize: 11, fontWeight: '600' },
  dockNote: { color: colors.muted, fontSize: 10, lineHeight: 15, textAlign: 'center' },
  permissionContent: { flexGrow: 1, justifyContent: 'center', padding: 20 },
  permissionCard: {
    backgroundColor: colors.white, borderWidth: 1, borderColor: colors.line,
    borderRadius: 13, padding: 24, gap: 16,
  },
  permissionTitle: { color: colors.ink, fontSize: 21, lineHeight: 30, fontWeight: '600' },
  permissionText: { color: colors.muted, fontSize: 14, lineHeight: 23 },
  permissionButton: {
    minHeight: 48, borderRadius: 7, backgroundColor: colors.green,
    alignItems: 'center', justifyContent: 'center', paddingHorizontal: 16,
  },
  permissionButtonText: { color: colors.white, fontSize: 14, fontWeight: '600' },
  temporaryNote: { backgroundColor: colors.tint, borderRadius: 9, padding: 14 },
  permissionGalleryButton: {
    minHeight: 44, justifyContent: 'center', alignItems: 'center',
    borderWidth: 1, borderColor: colors.line, borderRadius: 7, paddingHorizontal: 12,
  },
  permissionGalleryText: { color: colors.greenDark, fontSize: 14, fontWeight: '600' },
});
