import React, { useState, useEffect } from 'react';
import { StyleSheet, Text, View, TouchableOpacity, FlatList, Image, Alert, ScrollView, ActivityIndicator } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { getSavedPhotos, exportToCameraRoll, copyPhotoToClipboard, deleteSelectedPhotos } from './PhotoManager';
import Brand from './Brand';
import { colors } from './theme';

type Props = {
  onBack: () => void;
};

const numColumns = 3;
const gridPadding = 16;
const gridGap = 8;

export default function GalleryScreen({ onBack }: Props) {
  const [isSelecting, setIsSelecting] = useState(false);
  const [photos, setPhotos] = useState<string[]>([]);
  const [selectedPhotos, setSelectedPhotos] = useState<Set<string>>(new Set());
  const [previewUri, setPreviewUri] = useState<string | null>(null);
  const [isProcessing, setIsProcessing] = useState(false);
  const [gridWidth, setGridWidth] = useState(0);
  const [previewSize, setPreviewSize] = useState({ width: 0, height: 0 });
  const { width: previewWidth, height: previewHeight } = previewSize;
  const [isPreviewScrolling, setIsPreviewScrolling] = useState(false);

  useEffect(() => {
    loadPhotos();
  }, []);

  const loadPhotos = async () => {
    const uris = await getSavedPhotos();
    setPhotos(uris.reverse()); // latest first
  };

  const toggleSelection = (uri: string) => {
    if (isProcessing) return;
    setIsSelecting(true);
    const newSelected = new Set(selectedPhotos);
    if (newSelected.has(uri)) {
      newSelected.delete(uri);
    } else {
      newSelected.add(uri);
    }
    setSelectedPhotos(newSelected);
  };

  const handleExport = async () => {
    if (selectedPhotos.size === 0 || isProcessing) return;
    const urisToExport = Array.from(selectedPhotos);
    setIsProcessing(true);
    try {
      const success = await exportToCameraRoll(urisToExport);
      if (success) {
        Alert.alert("保存完了", `${urisToExport.length}枚の画像をカメラロールに保存しました！`);
        setSelectedPhotos(new Set()); // clear selection
      } else {
        Alert.alert("エラー", "画像の保存に失敗しました。");
      }
    } catch (error) {
      console.error('Photo export failed', error);
      Alert.alert("エラー", "画像の保存に失敗しました。");
    } finally {
      setIsProcessing(false);
    }
  };

  const handleDeleteSelected = () => {
    if (selectedPhotos.size === 0 || isProcessing) return;
    const uris = Array.from(selectedPhotos);
    Alert.alert('選択した写真を削除', `${uris.length}枚をアプリ内から削除します。写真アプリに保存した画像は残ります。`, [
      { text: 'キャンセル', style: 'cancel' },
      { text: '削除する', style: 'destructive', onPress: async () => {
        setIsProcessing(true);
        try {
          await deleteSelectedPhotos(uris);
        } catch (error) {
          console.error('Delete failed', error);
          Alert.alert('エラー', '一部の写真を削除できませんでした。');
        } finally {
          setSelectedPhotos(new Set());
          try {
            await loadPhotos();
          } catch (error) {
            console.error('Gallery refresh failed', error);
            Alert.alert('エラー', 'ギャラリーを再読み込みしてください。');
          }
          setIsProcessing(false);
        }
      } },
    ]);
  };

  const handlePreviewAction = async (action: 'copy' | 'save') => {
    if (!previewUri || isProcessing || isPreviewScrolling) return;
    setIsProcessing(true);
    try {
      if (action === 'copy') {
        await copyPhotoToClipboard(previewUri);
        Alert.alert('コピー完了', '画像をコピーしました。ほかのアプリに貼り付けできます。');
      } else {
        const success = await exportToCameraRoll([previewUri]);
        Alert.alert(success ? '保存完了' : '保存できませんでした',
          success ? '写真アプリに保存しました。' : '写真へのアクセス許可を確認してください。');
      }
    } catch (error) {
      console.error('Photo action failed', error);
      Alert.alert('エラー', action === 'copy' ? '画像のコピーに失敗しました。' : '画像の保存に失敗しました。');
    } finally {
      setIsProcessing(false);
    }
  };

  const handlePress = (uri: string) => {
    if (isProcessing) return;
    if (isSelecting) {
      toggleSelection(uri);
    } else {
      setPreviewUri(uri);
    }
  };

  const imageSize = Math.max(44, (gridWidth - gridPadding * 2 - gridGap * (numColumns - 1)) / numColumns);
  const renderItem = ({ item, index }: { item: string; index: number }) => {
    const isSelected = selectedPhotos.has(item);
    return (
      <TouchableOpacity
        style={[styles.imageContainer, { width: imageSize, height: imageSize }, isProcessing && styles.disabled]}
        accessibilityRole="button"
        accessibilityLabel={`写真 ${index + 1}`}
        accessibilityHint={isSelecting ? 'タップして選択を切り替えます' : 'タップして表示、長押しで選択します'}
        accessibilityState={{ selected: isSelected, disabled: isProcessing }}
        disabled={isProcessing}
        onPress={() => handlePress(item)}
        onLongPress={() => toggleSelection(item)}
      >
        <Image source={{ uri: item }} style={styles.image} />
        {isSelected && (
          <View style={styles.selectedOverlay} pointerEvents="none">
            <View style={styles.checkCircle}><Text style={styles.checkmark}>✓</Text></View>
          </View>
        )}
      </TouchableOpacity>
    );
  };

  const processingIndicator = isProcessing ? (
    <View style={styles.processing} accessibilityLiveRegion="polite">
      <ActivityIndicator color={colors.green} />
      <Text style={styles.bodyText}>処理中…</Text>
    </View>
  ) : null;

  if (previewUri) {
    const actionsDisabled = isProcessing || isPreviewScrolling;
    const updatePreview = (offset: number) => {
      const index = Math.max(0, Math.min(photos.length - 1, Math.round(offset / previewWidth)));
      if (photos[index]) setPreviewUri(photos[index]);
    };
    return (
      <SafeAreaView style={styles.container}>
        <ScrollView style={styles.previewChrome} contentContainerStyle={styles.previewHeader}>
          <TouchableOpacity
            style={[styles.navButton, actionsDisabled && styles.disabled]}
            accessibilityRole="button" accessibilityLabel="プレビューを閉じる"
            accessibilityState={{ disabled: actionsDisabled }} disabled={actionsDisabled}
            onPress={() => { setPreviewUri(null); setIsPreviewScrolling(false); }}
          >
            <Text style={styles.navButtonText}>✕ 閉じる</Text>
          </TouchableOpacity>
          <Text style={styles.photoCounter} accessibilityLiveRegion="polite">
            {photos.indexOf(previewUri) + 1} / {photos.length} 枚
          </Text>
        </ScrollView>
        <View
          style={styles.previewCanvas}
          onLayout={(event) => {
            const { width, height } = event.nativeEvent.layout;
            if (width !== previewWidth || height !== previewHeight) {
              setPreviewSize({ width, height });
              if (width !== previewWidth) setIsPreviewScrolling(false);
            }
          }}
        >
          {previewWidth > 0 && previewHeight > 0 && (
            <FlatList
              key={`preview-${previewWidth}`}
              style={styles.list}
              data={photos}
              horizontal
              pagingEnabled
              scrollEnabled={!isProcessing}
              showsHorizontalScrollIndicator={false}
              keyExtractor={(uri) => uri}
              initialScrollIndex={Math.max(0, photos.indexOf(previewUri))}
              getItemLayout={(_, index) => ({ length: previewWidth, offset: previewWidth * index, index })}
              scrollEventThrottle={16}
              onScroll={(event) => updatePreview(event.nativeEvent.contentOffset.x)}
              onScrollBeginDrag={() => setIsPreviewScrolling(true)}
              onMomentumScrollBegin={() => setIsPreviewScrolling(true)}
              onScrollEndDrag={(event) => {
                if (!event.nativeEvent.velocity?.x) {
                  updatePreview(event.nativeEvent.contentOffset.x);
                  setIsPreviewScrolling(false);
                }
              }}
              onMomentumScrollEnd={(event) => {
                updatePreview(event.nativeEvent.contentOffset.x);
                setIsPreviewScrolling(false);
              }}
              renderItem={({ item, index }) => (
                <View style={[styles.previewPage, { width: previewWidth, height: previewHeight }]}>
                  <Image source={{ uri: item }} style={styles.previewImage} resizeMode="contain"
                    accessible accessibilityLabel={`写真 ${index + 1}`} />
                </View>
              )}
            />
          )}
        </View>
        <ScrollView style={styles.previewChrome} contentContainerStyle={styles.previewFooter}>
          <Text style={styles.sectionLabel}>PHOTO</Text>
          <Text style={styles.bodyText}>左右にスワイプして写真を表示</Text>
          <View style={styles.previewActions}>
            <TouchableOpacity
              style={[styles.button, styles.outlineButton, styles.previewAction, actionsDisabled && styles.disabled]}
              accessibilityRole="button" accessibilityLabel="表示中の写真をコピー"
              accessibilityState={{ disabled: actionsDisabled }} disabled={actionsDisabled}
              onPress={() => handlePreviewAction('copy')}
            >
              <Text style={styles.outlineButtonText}>コピー</Text>
            </TouchableOpacity>
            <TouchableOpacity
              style={[styles.button, styles.primaryButton, styles.previewAction, actionsDisabled && styles.disabled]}
              accessibilityRole="button" accessibilityLabel="表示中の写真を写真アプリに保存"
              accessibilityState={{ disabled: actionsDisabled }} disabled={actionsDisabled}
              onPress={() => handlePreviewAction('save')}
            >
              <Text style={styles.primaryButtonText}>写真に保存</Text>
            </TouchableOpacity>
          </View>
          {processingIndicator}
        </ScrollView>
      </SafeAreaView>
    );
  }

  return (
    <SafeAreaView style={styles.container}>
      <FlatList
        key="grid"
        style={styles.list}
        onLayout={(event) => setGridWidth(event.nativeEvent.layout.width)}
        data={gridWidth > 0 ? photos : []}
        extraData={{ selectedPhotos, isProcessing, imageSize, isSelecting }}
        contentContainerStyle={styles.gridContent}
        columnWrapperStyle={styles.gridRow}
        keyExtractor={(item) => item}
        numColumns={numColumns}
        renderItem={renderItem}
        ListHeaderComponent={
          <View style={styles.galleryHeader}>
            <Brand />
            <View style={styles.navigation}>
              <TouchableOpacity onPress={onBack} style={[styles.navButton, isProcessing && styles.disabled]}
                accessibilityRole="button" accessibilityLabel="カメラへ戻る"
                accessibilityState={{ disabled: isProcessing }} disabled={isProcessing}>
                <Text style={styles.navButtonText}>◀ カメラへ</Text>
              </TouchableOpacity>
              <TouchableOpacity style={[styles.navButton, isProcessing && styles.disabled]}
                accessibilityRole="button" accessibilityLabel={isSelecting ? '写真の選択を完了' : '写真を選択'}
                accessibilityState={{ disabled: isProcessing }} disabled={isProcessing}
                onPress={() => {
                  setIsSelecting(!isSelecting);
                  setSelectedPhotos(new Set());
                }}>
                <Text style={styles.navButtonText}>{isSelecting ? '完了' : '選択'}</Text>
              </TouchableOpacity>
            </View>
            <Text style={styles.sectionLabel}>GALLERY</Text>
            <Text style={styles.title}>ギャラリー</Text>
            <Text style={styles.bodyText}>{photos.length} 枚の写真{isSelecting ? ' · 写真をタップして選択' : ''}</Text>
            {selectedPhotos.size === 0 && processingIndicator}
          </View>
        }
        ListEmptyComponent={photos.length === 0 ? (
          <View style={styles.emptyCard}>
            <View style={styles.emptyIllustration} accessible={false}>
              <View style={styles.emptyLens} />
            </View>
            <Text style={styles.emptyTitle}>まだ写真がありません</Text>
            <Text style={styles.bodyText}>カメラに戻って、残しておきたい学びを撮影しましょう。撮影した写真はここに並びます。</Text>
            <TouchableOpacity style={[styles.button, styles.primaryButton, isProcessing && styles.disabled]}
              accessibilityRole="button" accessibilityLabel="カメラに戻って撮影する"
              accessibilityState={{ disabled: isProcessing }} disabled={isProcessing} onPress={onBack}>
              <Text style={styles.primaryButtonText}>◀ カメラへ</Text>
            </TouchableOpacity>
          </View>
        ) : null}
      />
      {selectedPhotos.size > 0 && (
        <ScrollView style={styles.selectionScroll} contentContainerStyle={styles.selectionPadding}>
          <View style={styles.selectionCard}>
            <Text style={styles.sectionLabel}>SELECTED</Text>
            <Text style={styles.selectionTitle}>{selectedPhotos.size} 枚を選択中</Text>
            <TouchableOpacity style={[styles.button, styles.primaryButton, isProcessing && styles.disabled]}
              accessibilityRole="button" accessibilityState={{ disabled: isProcessing }}
              disabled={isProcessing} onPress={handleExport}>
              <Text style={styles.primaryButtonText}>選択した {selectedPhotos.size} 枚をカメラロールへ保存</Text>
            </TouchableOpacity>
            <TouchableOpacity style={[styles.button, styles.deleteButton, isProcessing && styles.disabled]}
              accessibilityRole="button" accessibilityState={{ disabled: isProcessing }}
              disabled={isProcessing} onPress={handleDeleteSelected}>
              <Text style={styles.deleteButtonText}>選択した {selectedPhotos.size} 枚を削除</Text>
            </TouchableOpacity>
            {processingIndicator}
          </View>
        </ScrollView>
      )}
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: colors.paper },
  list: { flex: 1 },
  gridContent: { paddingHorizontal: gridPadding, paddingBottom: 16 },
  gridRow: { gap: gridGap, marginBottom: gridGap },
  galleryHeader: { paddingTop: 16, paddingBottom: 20, gap: 8 },
  navigation: { flexDirection: 'row', flexWrap: 'wrap', justifyContent: 'space-between', gap: 8, marginVertical: 8 },
  navButton: { minHeight: 44, minWidth: 44, paddingVertical: 12, paddingHorizontal: 10, justifyContent: 'center' },
  navButtonText: { color: colors.greenDark, fontSize: 15, fontWeight: '600' },
  sectionLabel: { color: colors.green, fontSize: 11, fontWeight: '700', letterSpacing: 2 },
  title: { color: colors.ink, fontSize: 28, fontWeight: '600' },
  bodyText: { color: colors.muted, fontSize: 14, lineHeight: 22 },
  imageContainer: { borderRadius: 10, overflow: 'hidden', backgroundColor: colors.line },
  image: { width: '100%', height: '100%' },
  selectedOverlay: { ...StyleSheet.absoluteFill, backgroundColor: 'rgba(66, 117, 87, 0.38)', borderWidth: 2, borderColor: colors.green, borderRadius: 10, alignItems: 'flex-end', padding: 6 },
  checkCircle: { width: 28, height: 28, borderRadius: 14, backgroundColor: colors.green, alignItems: 'center', justifyContent: 'center' },
  checkmark: { color: colors.white, fontSize: 17, fontWeight: '700' },
  emptyCard: { backgroundColor: colors.white, borderWidth: 1, borderColor: colors.line, borderRadius: 13, padding: 22, gap: 18, marginBottom: 8 },
  emptyIllustration: { width: 64, height: 50, borderRadius: 12, borderWidth: 2, borderColor: colors.green, backgroundColor: colors.tint, alignItems: 'center', justifyContent: 'center' },
  emptyLens: { width: 25, height: 25, borderRadius: 13, borderWidth: 2, borderColor: colors.green },
  emptyTitle: { color: colors.ink, fontSize: 20, fontWeight: '600' },
  button: { minHeight: 48, minWidth: 44, borderRadius: 8, paddingHorizontal: 14, paddingVertical: 13, alignItems: 'center', justifyContent: 'center', borderWidth: 1 },
  primaryButton: { backgroundColor: colors.green, borderColor: colors.green },
  primaryButtonText: { color: colors.white, fontSize: 15, fontWeight: '600', textAlign: 'center' },
  outlineButton: { backgroundColor: colors.white, borderColor: colors.green },
  outlineButtonText: { color: colors.greenDark, fontSize: 15, fontWeight: '600', textAlign: 'center' },
  deleteButton: { backgroundColor: colors.dangerTint, borderColor: colors.dangerTint },
  deleteButtonText: { color: colors.danger, fontSize: 15, fontWeight: '600', textAlign: 'center' },
  disabled: { opacity: 0.5 },
  selectionScroll: { flexGrow: 0, flexShrink: 1, maxHeight: '45%' },
  selectionPadding: { paddingHorizontal: 16, paddingTop: 8, paddingBottom: 12 },
  selectionCard: { borderRadius: 13, borderWidth: 1, borderColor: colors.line, backgroundColor: colors.white, padding: 14, gap: 10 },
  selectionTitle: { color: colors.ink, fontSize: 17, fontWeight: '600' },
  processing: { flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 8, paddingVertical: 4 },
  previewChrome: { flexGrow: 0, flexShrink: 1, maxHeight: '35%' },
  previewHeader: { flexDirection: 'row', flexWrap: 'wrap', alignItems: 'center', justifyContent: 'space-between', gap: 8, paddingHorizontal: 16, paddingVertical: 8 },
  photoCounter: { color: colors.muted, fontSize: 14, paddingHorizontal: 10, paddingVertical: 12 },
  previewCanvas: { flex: 1, minHeight: 80, backgroundColor: colors.camera },
  previewPage: { justifyContent: 'center' },
  previewImage: { width: '100%', height: '100%' },
  previewFooter: { padding: 16, gap: 10 },
  previewActions: { flexDirection: 'row', flexWrap: 'wrap', gap: 10 },
  previewAction: { flexGrow: 1, flexBasis: 120 },
});
