import { StatusBar } from 'expo-status-bar';
import React, { useState, useEffect } from 'react';
import { StyleSheet, View, Alert, Text, ActivityIndicator } from 'react-native';
import { SafeAreaProvider, SafeAreaView, initialWindowMetrics } from 'react-native-safe-area-context';
import CameraScreen from './src/CameraScreen';
import GalleryScreen from './src/GalleryScreen';
import { hasExistingPhotos, deleteAllPhotos } from './src/PhotoManager';
import Brand from './src/Brand';
import { colors } from './src/theme';

type Screen = 'camera' | 'gallery';

export default function App() {
  const [currentScreen, setCurrentScreen] = useState<Screen>('camera');
  const [isReady, setIsReady] = useState(false);

  useEffect(() => {
    checkExistingData();
  }, []);

  const checkExistingData = async () => {
    try {
      const exists = await hasExistingPhotos();
      if (exists) {
        Alert.alert(
          "前回の画像が残っています",
          "前回の授業の画像が残っています。削除して新しく始めますか？",
          [
            { 
              text: "そのまま残す", 
              style: "cancel",
              onPress: () => setIsReady(true)
            },
            { 
              text: "削除して始める", 
              style: "destructive",
              onPress: async () => {
                await deleteAllPhotos();
                setIsReady(true);
              }
            }
          ]
        );
      } else {
        setIsReady(true);
      }
    } catch (e) {
      console.error(e);
      setIsReady(true);
    }
  };

  return (
    <SafeAreaProvider initialMetrics={initialWindowMetrics}>
      <View style={styles.container}>
        <StatusBar style="dark" />
        {!isReady ? (
          <SafeAreaView style={styles.loading}>
            <Brand />
            <View style={styles.loadingCard}>
              <ActivityIndicator color={colors.green} />
              <Text style={styles.loadingTitle}>授業の準備中</Text>
              <Text style={styles.loadingText}>一時保存した写真を確認しています。</Text>
            </View>
          </SafeAreaView>
        ) : currentScreen === 'camera' ? (
          <CameraScreen onGoToGallery={() => setCurrentScreen('gallery')} />
        ) : (
          <GalleryScreen onBack={() => setCurrentScreen('camera')} />
        )}
      </View>
    </SafeAreaProvider>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.paper,
  },
  loading: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    paddingHorizontal: 24,
    gap: 28,
  },
  loadingCard: {
    alignSelf: 'stretch',
    alignItems: 'center',
    padding: 24,
    gap: 12,
    backgroundColor: colors.white,
    borderWidth: 1,
    borderColor: colors.line,
    borderRadius: 13,
  },
  loadingTitle: {
    color: colors.ink,
    fontSize: 18,
    fontWeight: '600',
  },
  loadingText: {
    color: colors.muted,
    fontSize: 14,
    textAlign: 'center',
    lineHeight: 21,
  },
});
